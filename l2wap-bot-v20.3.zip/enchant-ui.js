/* Панель заточки: явный запуск, основные правила сразу, дополнительные раскрываются. */
(function (root) {
 'use strict';
 const DEFAULT = Object.freeze({enabled:false,queue:[],scrollPolicy:'blessed',ordinaryUntil:3,maxAttempts:0,maxScrolls:0,maxAdena:0,maxConsecutiveFails:2,maxDropFromStart:1,maxDropFromPeak:2,delayMs:1500,purchase:false,colBudget:0});
 const POLICIES = {blessed:'Благословенные',ordinary:'Обычные',mixed:'Обычные до уровня, затем благословенные'};
 const FIELDS = [['maxAttempts','Не более попыток',0,100000],['maxScrolls','Не более свитков',0,100000],['maxConsecutiveFails','Пауза после неудач подряд',0,100000],['maxDropFromStart','Допустимое снижение от начала',0,25],['maxDropFromPeak','Допустимое снижение от лучшего уровня',0,25]];
 const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clone = s => JSON.parse(JSON.stringify(s));
 const validInput = el => {const disabled=el.disabled;el.disabled=false;try{return el.checkValidity();}finally{el.disabled=disabled;}};
 const opts = (list,value,inherit=false) => (inherit?'<option value="">Общее правило</option>':'')+Object.entries(list).map(([v,t])=>`<option value="${esc(v)}" ${v===value?'selected':''}>${esc(t)}</option>`).join('');
 const number = n => Number(n || 0).toLocaleString('ru-RU');
 const percent = p => Number.isFinite(p)?(p*100).toLocaleString('ru-RU',{maximumFractionDigits:1})+'%':'—';
 const locationLabel = q => q.locationLabel || (q.eqSlot?'Надето':'В сумке');
 const describe = q => `${q.name || '#'+q.itemId} +${q.level} · ${q.grade} · ${locationLabel(q)}`;
 function scanSummary(scan,char) {
  if(!scan||scan.char&&scan.char!==char)return 'Нажмите «Обновить вещи», чтобы прочитать инвентарь персонажа.';
  if(!scan.ok)return 'Не удалось прочитать вещи: '+(scan.reason||'повторите обновление.');
  const rows=scan.items||[],available=rows.filter(q=>!q.ambiguous&&q.level<25).length;
  const max=rows.filter(q=>q.level>=25).length,ambiguous=rows.filter(q=>q.ambiguous&&q.level<25).length;
  return (available?'Доступно вещей: '+available+'.':'Нет подходящих вещей для добавления.')+(max?' Уже +25: '+max+'.':'')+(ambiguous?' Неоднозначных экземпляров: '+ambiguous+' — разделите одинаковые вещи в игре и обновите список.':'');
 }
 function scrollSummary(scan,char) {
  if(!scan?.ok||scan.char&&scan.char!==char)return 'Наличие свитков появится после обновления вещей.';
  const rows=[];
  for(const [i,grade] of ['D','C','B','A','S'].entries())for(const [k,kind] of ['Обычные','Благословенные'].entries())for(const [j,target] of ['броня','оружие'].entries()) {
   const qty=+scan.scrolls?.[910510+i*2+k*10+j]||0;if(qty>0)rows.push(kind+' · '+grade+' · '+target+': '+number(qty));
  }
  return rows.length?rows.join('; '):'Подходящих свитков в сумке нет. Покупки отключены.';
 }
 function startSteps(state,cfg,pending) {
  const selected=Array.isArray(state.cfg?.autoTasks)?state.cfg.autoTasks.includes('enchant'):state.cfg?.enchantMode===true;
  return [!selected&&'Выберите «Автозаточка» в разрешённых задачах.',!cfg.queue.length&&'Добавьте конкретную вещь.',cfg.maxAttempts<1&&'Укажите положительный лимит попыток.',cfg.maxScrolls<1&&'Укажите положительный лимит свитков.',!cfg.enabled&&'Разрешите попытки заточки.',!state.on&&'Нажмите общий «Старт».',pending&&'Дождитесь подтверждения предыдущей попытки или сверьте результат.'].filter(Boolean);
 }
 function mount(node, adapter) {
  let state, cfg, busy=false, message='', renderId=0, archiveConfirm='', selectedCandidate='', openDetails=new Set();
  const qByKey = key => cfg.queue.find(q=>q.key===key);
  async function action(fn) { if(busy)return;busy=true;renderId++;node.querySelectorAll('button,input,select').forEach(el=>el.disabled=true);try{await fn();message='';}catch(e){message=String(e?.message||e);}finally{try{await render(true);}finally{busy=false;}} }
  async function persist() {await adapter.saveConfig(clone(cfg), {char:state.rt?.char||''});}
  const candidates = () => ((!state.rt?.enchantScan?.char||state.rt.enchantScan.char===state.rt?.char?state.rt?.enchantScan?.items:null) || state.candidates || []).filter(q=>!q.ambiguous && q.level<25).map((q,i)=>({...q,locationLabel:q.locationLabel||((q.eqSlot?'Надето · '+({l1:'правая рука',l2:'левая рука',l3:'торс',l4:'ноги',lh:'голова',lg:'руки',lf:'ступни'}[q.eqSlot]||q.eqSlot):'Сумка · экземпляр '+(i+1))+(q.history?.length?' · рост '+q.history.map(x=>({magic:'М',physical:'Ф',balanced:'Ф+М'}[x]||'?')).join('→'):''))}));
  const issues = () => [!cfg.queue.length&&'Добавьте конкретную вещь.',cfg.maxAttempts<1&&'Укажите положительный лимит попыток.',cfg.maxScrolls<1&&'Укажите положительный лимит свитков.'].filter(Boolean);
  function numericFields(values,attr,inherit=false,fields=FIELDS) {return fields.map(([k,label,min,max])=>`<label>${label}<input type="number" min="${min}" max="${max}" ${attr} data-field="${k}" value="${values[k]??''}" ${inherit?'placeholder="Общее правило"':''}></label>`).join('');}
  async function render(force=false) {
   if(busy&&!force)return;
   const generation=++renderId,next=await adapter.getState();if(generation!==renderId)return;
   if(state&&state.rt?.char!==next.rt?.char){selectedCandidate='';openDetails.clear();archiveConfirm='';}else node.querySelectorAll('details[data-detail]').forEach(el=>{if(el.open)openDetails.add(el.dataset.detail);else openDetails.delete(el.dataset.detail);});
   state=next;cfg={...DEFAULT,...state.cfg?.enchant,queue:clone(state.cfg?.enchant?.queue||[])};
   const session=state.rt?.enchant||{},analysis=state.analytics||session,T=analysis.totals||{},pending=analysis.pending,inventory=candidates();
   const modeSelected=Array.isArray(state.cfg?.autoTasks)?state.cfg.autoTasks.includes('enchant'):state.cfg?.enchantMode===true,canStart=modeSelected&&cfg.enabled&&!issues().length&&!!state.on&&!pending;
   const steps=startSteps(state,cfg,pending);
   const status=message || (session.reason==='Уровень в панели устарел'?'Страница заточки устарела. Обновите вкладку игры, затем нажмите «Продолжить серию».':session.reason) || (!modeSelected?'Выберите режим «Автозаточка»':!cfg.enabled?'Попытки выключены':!state.on?'Ожидает старта бота':issues()[0]||({idle:'Готово к новой серии',running:'Серия выполняется',paused:'Серия на паузе',done:'Все цели достигнуты',unknown:'Результат попытки ещё не подтверждён'}[session.status]||'Готово'));
   node.innerHTML=`<div class="ench-section">${node.dataset.embedded?'':'<h2>Заточка оружия и брони</h2>'}
    <p class="ench-note">Только выбранные вещи и имеющиеся свитки. Общий «Стоп» прекращает новые попытки.</p>
    <div class="ench-status ${message?'ench-error':''}" role="status">${esc(status)}${pending?'\nОжидаю подтверждение уже отправленной попытки. Повтор не запущен.':''}</div>
    <h3>Очередь вещей</h3><div class="ench-row"><button data-command="refresh">Обновить вещи</button><select data-candidate aria-label="Добавить конкретную вещь"><option value="">Выберите вещь</option>${inventory.map((q,i)=>`<option value="${i}" ${selectedCandidate===JSON.stringify([q.targetInstanceId,q.fingerprint])?'selected':''}>${esc(describe(q))}</option>`).join('')}</select><button data-add>Добавить</button></div>
    <p class="ench-note" data-scan-status>${esc(scanSummary(state.rt?.enchantScan,state.rt?.char))}</p>
    <p class="ench-note">Для одинаковых вещей выбирайте нужный экземпляр по месту, текущему уровню и характеристикам.</p>
    <div data-queue>${cfg.queue.length?cfg.queue.map((q,i)=>item(q,i,session)).join(''):'<p class="ench-note">Очередь пустая. Ничего не будет заточено.</p>'}</div>
    <h3>Свитки и лимиты</h3><div class="ench-grid"><label>Какие свитки использовать<select data-cfg="scrollPolicy">${opts(POLICIES,cfg.scrollPolicy)}</select></label>${cfg.scrollPolicy==='mixed'?`<label>Обычные свитки — до уровня<input data-cfg="ordinaryUntil" type="number" min="0" max="25" value="${cfg.ordinaryUntil}"></label>`:''}${numericFields(cfg,'data-global',false,FIELDS.slice(0,2))}</div>
    <p class="ench-note" data-scroll-stock>${esc(scrollSummary(state.rt?.enchantScan,state.rt?.char))}</p>
    <p class="ench-note">0 попыток или свитков — запрет. Только свитки из сумки: без покупок, адены, Coin of Luck и FA.</p>
    <details data-detail="limits"><summary>Дополнительные ограничения</summary><div class="ench-grid">${numericFields(cfg,'data-global',false,FIELDS.slice(2))}<label>Пауза между попытками, мс<input type="number" data-cfg="delayMs" min="500" max="60000" value="${cfg.delayMs}"></label></div><p class="ench-note">Правила отдельной вещи могут быть строже общих лимитов.</p></details>
    <label class="ench-row ench-enable"><input type="checkbox" data-cfg="enabled" ${cfg.enabled?'checked':''}> Разрешить попытки заточки</label>
    ${steps.length?`<div class="ench-note" data-start-steps>Для запуска серии:<ul>${steps.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></div>`:''}
    <div class="ench-row">${session.status==='running'?'<button class="ench-primary" data-command="pause">Пауза</button>':session.runId&&session.status!=='done'?`<button class="ench-primary" data-command="resume" ${canStart&&session.status==='paused'?'':'disabled'}>Продолжить серию</button>`:`<button class="ench-primary" data-command="start" ${canStart?'':'disabled'}>Начать серию</button>`}${pending?'<button data-command="reconcile">Сверить результат</button>':''}</div>
    ${pending?.state==='unknown'?`<details open><summary>Неопределённый результат</summary><p class="ench-note">${esc((session.items||[]).find(x=>x.key===pending.key)?.name||'Выбранная вещь')}: перед попыткой +${pending.before}. Исход не подтверждён. При завершении серии попытка и один свиток останутся в истории как неопределённые; заточка выключится, очередь будет очищена. Для новой серии понадобится заново выбрать вещи.</p><button data-archive-begin>Завершить серию с неизвестным результатом</button>${archiveConfirm===pending.id?'<p class="ench-note">Сохранить этот неопределённый исход и очистить очередь?</p><button data-command="archiveUnknown">Да, сохранить исход и очистить очередь</button>':''}</details>`:''}
    ${!modeSelected?'<p class="ench-note">Настройки сохранены. Выберите «Автозаточка» в разрешённых задачах или кнопкой над настройками.</p>':!state.on?'<p class="ench-note">Режим выбран, бот остановлен. Нажмите общий «Старт», затем начните или продолжите серию.</p>':''}
    <details data-detail="results"><summary>Результаты и история</summary><h3>Результаты этой серии</h3><div class="ench-metrics">${[[T.attempts,'попыток подтверждено'],[T.successes,'успешных'],[T.failures,'неудачных'],[T.scrolls,'свитков списано'],[T.adena,'адены списано'],[(T.unknown||0)+(pending?.state==='unknown'?1:0),'исход неизвестен']].map(([v,t])=>`<div><b>${number(v)}</b><span>${t}</span></div>`).join('')}</div>
    <p class="ench-note">Неизвестный исход не считается успехом или неудачей. ${number((T.reservedScrolls||0)+(pending?1:0))} свитков зарезервировано для ожидающей или неподтверждённой попытки.</p>
    ${rates(analysis.rates || Object.entries(T.byScroll||{}).map(([id,b])=>({...b,scrollId:+id,n:b.attempts,observed:b.attempts?b.successes/b.attempts:null})))}
    <details data-detail="estimate"><summary>Расчёт по правилам игры</summary><p class="ench-note">Модель использует опубликованные шансы и снижение уровня на 1 при неудаче, минимум +0. Она не учитывает лимиты серии и нехватку свитков; это не прогноз текущей ограниченной серии. Время показывается только после трёх измеренных попыток.</p>${!pending&&analysis.estimates?.length?`<table class="ench-table"><thead><tr><th>Вещь / цель</th><th>Среднее число свитков</th><th>Время по нашей скорости</th></tr></thead><tbody>${analysis.estimates.map(x=>`<tr><td>${esc((session.items||[]).find(i=>i.key===x.key)?.name||'Предмет')}<br>+${x.from} → +${x.target}</td><td>${Number.isFinite(x.expectedScrolls)?x.expectedScrolls.toLocaleString('ru-RU',{maximumFractionDigits:2}):'—'}</td><td>${Number.isFinite(x.estimatedMs)?Math.ceil(x.estimatedMs/60000).toLocaleString('ru-RU')+' мин':'Мало данных'}</td></tr>`).join('')}</tbody></table>`:'<p class="ench-note">Расчёт появится для начатой серии с подтверждённым текущим уровнем.</p>'}</details>
    <details data-detail="history"><summary>История серии</summary>${history(analysis.history||[],session.items||[])}</details>
    <details data-detail="archive"><summary>Последние серии (${(state.rt?.enchantArchive||[]).length}/20)</summary>${(state.rt?.enchantArchive||[]).length?(state.rt.enchantArchive||[]).map(a=>`<p class="ench-note">${esc(new Date(a.finishedAt||a.archivedAt||a.startedAt).toLocaleString('ru-RU'))}: ${number(a.totals?.attempts)} попыток, ${number(a.totals?.scrolls)} свитков, ${number(a.totals?.unknown)} неизвестных исходов.</p>`).join(''):'<p class="ench-note">Сохранённых серий пока нет.</p>'}</details>
    <div class="ench-row"><button data-command="reset" ${session.runId&&!pending&&session.status!=='running'?'':'disabled'}>Сохранить серию в историю</button><button data-export>Скачать результаты</button></div>
    </details></div>`;
   node.querySelectorAll('details[data-detail]').forEach(el=>{el.open=openDetails.has(el.dataset.detail);});
   wire();
  }
  function item(q,index,session) {
   const r=q.rules||{},seen=(session.items||[]).find(x=>x.key===q.key),stats=q.statsLabel||[q.pb!=null&&`Бонус физ. атаки ${q.pb}`,q.mb!=null&&`Бонус маг. атаки ${q.mb}`].filter(Boolean).join(' · ');
   return `<article class="ench-item" data-key="${esc(q.key)}"><strong>${index+1}. ${esc(describe(q))}</strong><p class="ench-note">${esc(stats)}${seen?` · начало +${seen.start} → сейчас +${seen.level} · максимум +${seen.peak}`:''}</p><div class="ench-grid"><label>Цель, +N<input data-item="targetLevel" type="number" min="1" max="25" value="${q.targetLevel}"></label>${q.category==='weapon'||q.kind==='weapon'?`<label>Бонус оружия<select data-item="weaponMode">${opts({magic:'Магическая атака',physical:'Физическая атака',balanced:'Смешанный'},q.weaponMode||'balanced')}</select></label>`:''}</div><details data-detail="item:${esc(q.key)}"><summary>Правила для этой вещи</summary><div class="ench-grid"><label>Свитки<select data-rule="scrollPolicy">${opts(POLICIES,r.scrollPolicy,true)}</select></label><label>Обычные — до уровня<input data-rule="ordinaryUntil" type="number" min="0" max="25" value="${r.ordinaryUntil??''}" placeholder="Общее правило"></label>${numericFields(r,'data-override',true)}</div></details><div class="ench-actions"><button data-move="-1" ${index?'':'disabled'} aria-label="Выше в очереди">↑</button><button data-move="1" ${index<cfg.queue.length-1?'':'disabled'} aria-label="Ниже в очереди">↓</button><button data-remove>Убрать из очереди</button></div></article>`;
  }
  function rates(rows) {return rows.length?`<table class="ench-table"><thead><tr><th>Свиток</th><th>Шанс игры</th><th>Наши результаты</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.label||'Свиток №'+r.scrollId)}</td><td>${percent(r.listed)}</td><td>${number(r.successes)} из ${number(r.n)} · ${percent(r.observed)}</td></tr>`).join('')}</tbody></table><p class="ench-note">Фактическая доля успехов основана только на завершённых попытках этой серии. При небольшой выборке она может сильно отличаться от шанса игры.</p>`:'<p class="ench-note">Ещё нет подтверждённых попыток. Правила игры: обычные свитки — 60%, благословенные — 100%; неудача обычного снижает уровень на 1, минимум +0.</p>';}
  function history(rows,items) {return rows.length?`<table class="ench-table"><thead><tr><th>Время / вещь</th><th>Уровень</th><th>Исход</th></tr></thead><tbody>${rows.slice(0,30).map(r=>`<tr><td>${esc(new Date(r.t).toLocaleTimeString('ru-RU'))}<br>${esc(items.find(i=>i.key===r.key)?.name||'Предмет')}</td><td>+${r.before??'?'} → +${r.after??'?'}</td><td>${r.status==='confirmed'?(r.success?'Успех':'Неудача'):'Не подтверждён'}</td></tr>`).join('')}</tbody></table>`:'<p class="ench-note">История появится после первой попытки.</p>';}
  function wire() {
   node.querySelector('[data-candidate]').onchange=el=>{const raw=el.target.value,q=raw===''?null:candidates()[+raw];selectedCandidate=q?JSON.stringify([q.targetInstanceId,q.fingerprint]):'';};
   node.querySelectorAll('[data-command]').forEach(el=>el.onclick=()=>action(async()=>{const context={char:state.rt?.char||'',pendingId:state.rt?.enchant?.pending?.id};if(el.dataset.command==='refresh')await adapter.refreshItems(context);else await adapter.command(el.dataset.command,context);
    if(el.dataset.command==='archiveUnknown'){const fresh=await adapter.getState();if(fresh.rt?.char!==context.char)throw Error('Персонаж изменился — обновите меню');cfg={...DEFAULT,...fresh.cfg?.enchant,enabled:false,queue:[]};await persist();archiveConfirm='';}
   }));
   const begin=node.querySelector('[data-archive-begin]');if(begin)begin.onclick=()=>{archiveConfirm=state.rt?.enchant?.pending?.id||'';render();};
   node.querySelector('[data-export]').onclick=()=>{const report={t:Date.now(),character:state.rt?.char||'',series:state.analytics||state.rt?.enchant||null,lastSeries:state.rt?.enchantArchive||[]};const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='l2bot-enchant-results.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
   node.querySelector('[data-add]').onclick=()=>action(async()=>{const raw=node.querySelector('[data-candidate]').value;if(raw==='')throw Error('Сначала выберите вещь.');const q=candidates()[+raw];if(!q)throw Error('Обновите список вещей.');if(cfg.queue.some(x=>x.targetInstanceId===q.targetInstanceId))throw Error('Этот экземпляр уже в очереди.');cfg.queue.push({...clone(q),key:crypto.randomUUID(),targetLevel:Math.min(25,q.level+1),weaponMode:q.weaponMode||'balanced',rules:{}});await persist();selectedCandidate='';});
   node.querySelectorAll('[data-cfg],[data-global]').forEach(el=>el.onchange=()=>action(async()=>{const k=el.dataset.cfg||el.dataset.field;if(!validInput(el))throw Error('Проверьте значение поля.');cfg[k]=el.type==='checkbox'?el.checked:el.tagName==='SELECT'?el.value:+el.value;await persist();}));
   node.querySelectorAll('[data-key]').forEach(row=>{const key=row.dataset.key;
    row.querySelectorAll('[data-item],[data-rule],[data-override]').forEach(el=>el.onchange=()=>action(async()=>{if(!validInput(el))throw Error('Проверьте значение поля.');const q=qByKey(key);if(!q)return;const k=el.dataset.item||el.dataset.rule||el.dataset.field,where=el.hasAttribute('data-item')?q:(q.rules ||= {});if(el.value==='')delete where[k];else where[k]=el.tagName==='SELECT'?el.value:+el.value;await persist();}));
    row.querySelector('[data-remove]').onclick=()=>action(async()=>{cfg.queue=cfg.queue.filter(q=>q.key!==key);await persist();});
    row.querySelectorAll('[data-move]').forEach(el=>el.onclick=()=>action(async()=>{const i=cfg.queue.findIndex(q=>q.key===key),j=i+(+el.dataset.move);if(j<0||j>=cfg.queue.length)return;[cfg.queue[i],cfg.queue[j]]=[cfg.queue[j],cfg.queue[i]];await persist();}));
   });
  }
  return {refresh:render,ready:render()};
 }
 root.L2EnchantUI={DEFAULT,mount,scanSummary,scrollSummary,startSteps};
})(globalThis);
