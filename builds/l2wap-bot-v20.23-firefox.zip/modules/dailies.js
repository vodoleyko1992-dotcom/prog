/* L2wap 10.0: дейлики и клановые задания (игрок 12.10: «клановые задания — делать на авто и получать бонусы; есть квесты общие ежедневные, типо дейлики»).
   Ежедневные задания игра засчитывает и выдаёт сама (claimed — сервер); боту остаётся дотянуть то, чего обычный фарм не даёт: 50 рыб и 1 РБ в день.
   Клановые задания: один активный таск на игрока, взять/помочь/сдать — свои POST с токеном страницы (как магазин TvT, без переходов). Зависимости только через env. */
(function (root) {
 'use strict';
 root.L2V7Factories = root.L2V7Factories || Object.create(null);
 root.L2V7Factories.dailies = function create_dailies(env) {
const location = env.routeLocation || root.location;
const DAILY_POLL = 10 * 60000, CLAN_POLL = 10 * 60000, FRESH = 20 * 60000, POST_GAP = 60000, FAIL_WAIT = 30 * 60000;
const FISH_MAX = 45 * 60000, RB_MAX = 90 * 60000;
const MODE_KEYS = ['fishMode', 'rbHuntMode', 'epicMode', 'catMode', 'zoneAuto'];
// клановые задания: что бот берёт сам, в порядке выгоды (kill_monsters — 1 Coin of Luck); штурм стены — никогда (осада)
const CLAN_TYPES = ['kill_monsters', 'earn_sp_from_monsters', 'earn_adena', 'kill_raid_boss'];
const DAILY_RU = { hunt_start_500: 'Убей 500 монстров', strong_enemy_20: 'Убей 1 РБ', raid_boss_participate: 'Участие в РБ', skill_master_50: '50 умений в бою',
  daily_playtime_2h: '2 часа в игре', chat_social_10: '10 сообщений в чате', damage_dealer_500k: '500 000 урона', fishing_catch_50: '50 рыб' };
const ssNum = k => { try { return +sessionStorage.getItem(k) || 0; } catch (e) { return 0; } };
const ssSet = (k, v) => { try { sessionStorage.setItem(k, String(v)); } catch (e) {} };
let dailyT = ssNum('l2bot-dqT'), clanT = ssNum('l2bot-ctT'), postT = 0, busy = null;
// 20.12 (решение игрока 17.10 10:56: «тур по РБ не должен быть авто включённым»): клановое «Вызов рейдового босса» — только когда игрок сам включил тур
const rbAllowed = () => !!env.cfg.rbHuntMode;
const canRun = () => env.on !== false && env.tabOwner !== false;
// ---------- заметки из ответов игры (страница или свой GET) ----------
function dailyNote(res) {
  if (!res || typeof res.tasks !== 'object') return false;
  const tasks = {};
  for (const [id, r] of Object.entries(res.tasks)) if (r && typeof r === 'object') tasks[id] = { have: +r.have || 0, need: +r.need || 0, done: !!r.done, claimed: !!r.claimed, score: +r.score || 0, place: r.place ?? null };
  const day = String(res.dayKey || '');
  const old = env.rt.daily;
  env.setRt({ daily: { day, t: Date.now(), tasks } });
  if (old?.day && old.day !== day) env.rec('B', 'дейлики', `новый игровой день ${day}`);
  for (const [id, r] of Object.entries(tasks)) if (r.done && !(old?.day === day && old.tasks?.[id]?.done)) env.rec('B', 'дейлики', `✓ ${DAILY_RU[id] || id}`);
  return true;
}
function clanNote(res) {
  if (!res || typeof res !== 'object') return false;
  if (res.error === 'clan_required') { env.setRt({ clanTasks: { t: Date.now(), noClan: true } }); return true; }
  if (!res.clan && !Array.isArray(res.taskDefinitions)) return false;
  const defs = (res.taskDefinitions || []).map(d => ({ id: d.id, n: d.nameRu || d.name || d.id, target: +d.target || 0, canTake: !!d.canTake, why: d.blockedReason || null, cdAt: d.cooldownEndsAt ? Date.parse(d.cooldownEndsAt) : null,
    reward: d.personalReward || {}, diamonds: +d.clanRewardDiamonds || 0 }));
  const active = (res.activeClanTasks || []).map(t => ({ id: t.id, type: t.taskType, progress: +t.progress || 0, target: +t.target || 0, owner: t.owner?.name || t.owner?.characterName || '', ownerId: t.owner?.id || t.owner?.characterId || '',
    helper: t.helper?.name || t.helper?.characterName || '', canHelp: !!t.canHelp, canClaim: !!t.canClaim, canCancel: !!t.canCancel, diamonds: +t.clanRewardDiamonds || 0 }));
  const old = env.rt.clanTasks;
  env.setRt({ clanTasks: { t: Date.now(), clan: { name: res.clan?.name || '', diamonds: +res.clan?.diamonds || 0 }, me: { active: res.me?.activeTaskId || null, id: res.me?.characterId || '' }, defs, active } });
  if (old?.clan && old.clan.diamonds != null && res.clan && +res.clan.diamonds > old.clan.diamonds) env.rec('B', 'клан', `алмазы клана: ${old.clan.diamonds} → ${res.clan.diamonds}`);
  return true;
}
// ---------- фоновый опрос (только GET) ----------
async function tick() {
  if (busy) return busy;
  const char = env.rt.char, active = () => canRun() && env.rt.char === char;
  const now = Date.now(), wantDaily = env.cfg.dailyAuto !== false && now - dailyT > DAILY_POLL,
    wantClan = env.cfg.clanTasks !== false && now - clanT > CLAN_POLL && (!env.rt.clanTasks?.noClan || now - (env.rt.clanTasks.t || 0) >= 6 * 3600000);
  if (!wantDaily && !wantClan) return null;
  busy = (async () => {
    try {
      if (wantDaily) { dailyT = Date.now(); ssSet('l2bot-dqT', dailyT); const r = await env.gameGet('/game/daily-quests'); const body = r?.ok ? await r.json().catch(() => null) : null; if (!active()) return; if (body) dailyNote(body); }
      if (wantClan) { clanT = Date.now(); ssSet('l2bot-ctT', clanT); const r = await env.gameGet('/game/clan-tasks'); const body = r ? await r.json().catch(() => null) : null; if (!active()) return;
        if (r?.ok && body || r?.status === 403 && body?.error === 'clan_required') clanNote(body);
        else env.rec('B', 'клан', `опрос заданий не принят: HTTP ${r?.status || '?'}${body?.error ? ' · ' + String(body.error).slice(0, 70) : ''}`);
      }
    } catch (e) { if (active()) env.rec('B', 'задания', `опрос не удался: ${String(e?.message || e).slice(0, 100)}`); } finally { busy = null; }
  })();
  return busy;
}
// ---------- клановые задания: сдать → помочь → взять ----------
function clanPlan() {
  const C = env.rt.clanTasks; if (!C || C.noClan || Date.now() - (C.t || 0) > FRESH) return null;
  const mine = C.active.find(t => t.id === C.me.active) || null;
  const claim = C.active.find(t => t.canClaim && (t.id === C.me.active || t.ownerId === C.me.id)); if (claim) return { kind: 'claim', task: claim, why: `сдать «${nameOf(C, claim.type)}» (${claim.progress}/${claim.target})` };
  if (mine) return null;
  const okType = t => CLAN_TYPES.includes(t) && (t !== 'kill_raid_boss' || rbAllowed());
  for (const ty of CLAN_TYPES) { const d = C.defs.find(x => x.id === ty && x.canTake); if (d && okType(ty)) return { kind: 'take', def: d, why: `взять «${d.n}»${d.reward.coinOfLuck ? ' (+' + d.reward.coinOfLuck + ' CoL)' : ''}` }; }
  const help = C.active.find(t => t.canHelp && okType(t.type)); if (help) return { kind: 'help', task: help, why: `помочь ${help.owner || 'соклановцу'} с «${nameOf(C, help.type)}»` };
  return null;
}
const nameOf = (C, type) => C.defs.find(d => d.id === type)?.n || type;
async function clanStep() {
  if (!canRun() || env.cfg.clanTasks === false || env.isBattle() || Date.now() - postT < POST_GAP) return false;
  const F = env.rt.clanTaskFail; if (F && Date.now() - (F.t || 0) < FAIL_WAIT) return false;
  const char = env.rt.char, kick = +env.rt.manualKickAt || 0;
  const active = () => canRun() && env.rt.char === char && (+env.rt.manualKickAt || 0) === kick && env.cfg.clanTasks !== false;
  const p = clanPlan(); if (!p) return false;
  postT = Date.now();
  const path = p.kind === 'take' ? `/game/clan-tasks/${encodeURIComponent(p.def.id)}/take` : `/game/clan-tasks/${encodeURIComponent(p.task.id)}/${p.kind}`;
  const r = await env.gamePost(path, {}).catch(() => null);
  const body = r ? await r.json().catch(() => ({})) : {};
  if (!active()) return false;
  if (r?.ok) { clanNote(body); clanT = Date.now(); env.rec('B', 'клан', `✓ ${p.why}${p.kind === 'claim' ? ` — клану +${p.task.diamonds} алмазов` : ''}`); return true; }
  const msg = body?.messageRu || body?.messageUk || body?.error || (r ? 'HTTP ' + r.status : 'нет ответа');
  env.rec('S', 'клан', `✗ ${p.why}: ${msg} — повтор через 30 мин`);
  await env.setRt({ clanTaskFail: { t: Date.now(), why: String(msg).slice(0, 120) } });
  if (r?.status === 409) { clanT = 0; }                 // состояние устарело — перечитать
  return true;
}
// ---------- дейлики: дотянуть 50 рыб и 1 РБ ----------
const snap = () => Object.fromEntries(MODE_KEYS.map(k => [k, !!(root.L2EngineCore?.rawTaskConfig(env.cfg) || env.cfg)[k]]));
const dailyTask = id => { const D = env.rt.daily; return D && Date.now() - (D.t || 0) < FRESH ? D.tasks?.[id] || null : null; };
const doneDay = kind => env.rt.dailyDone?.[kind] === env.rt.daily?.day;
// 15.10, лог 10:52: дейлик сам включил рыбалку посреди главы Диона (24/40 и 28/40).
// Кампания владеет задачей и между боями, при чтении/сдаче главы и после reload — не только при наличии открытых целей.
const campaignBusy = () => !!env.cfg.campaign || !!env.campEnabled?.() || !!(env.rt.campOnce && env.rt.campaignDue) || !!env.rt.storyJob;
const fishTakenOver = D => env.cfg.fishMode && (D.prev?.fishMode || (env.rt.fishTgt && !env.rt.fishTgt.done && (env.rt.fishTgt.t || 0) >= D.t));
// Дейлик использует уже подготовленную рыбалку. Открывать её за 10 млн/300 тыс. SP ради награды нельзя.
// Отрицательный ответ помним 5 минут; положительный содержит срок уже оплаченного времени.
async function fishReady(kick) {
  const char = env.rt.char, day = env.rt.daily?.day;
  const active = () => canRun() && (+env.rt.manualKickAt || 0) === kick && env.rt.char === char && env.rt.daily?.day === day;
  const check = env.rt.dailyFishCheck;
  if (check?.day === day && Date.now() - check.t < 5 * 60000) return null;
  let data = null;
  try { const r = await env.gameGet('/game/fishing/state'); if (r?.ok) data = await r.json(); } catch (e) {}
  if (!active()) return null;
  const ms = Number(data?.fishingTime?.remainingMs);
  const why = !data || typeof data.unlocked !== 'boolean' ? 'готовность рыбалки не подтверждена'
    : !data.unlocked ? 'рыболовные навыки ещё не изучены'
    : data.fishingSpot?.purchased !== true ? 'рыболовное место ещё не куплено'
    : data.fishingTime?.canFish !== true || !Number.isFinite(ms) || ms <= 0 ? 'нет оплаченного времени рыбалки' : '';
  if (!why) return { until: Date.now() + ms };
  await env.setRt({ dailyFishCheck: { day, t: Date.now(), why } });
  if (active()) env.rec('B', 'дейлики', `«50 рыб»: ${why} — пропускаю без покупок и обучения`);
  return null;
}
async function yieldCampaign(key, D, kick) {
  if (!campaignBusy()) return false;
  // Явная рыболовная цель/режим не принадлежат дейлику. Отцепляем лишь его таймер возврата.
  const ownFish = key === 'dailyFish' && fishTakenOver(D);
  if (ownFish) { if (sameDetour(key, D, kick)) await env.setRt({ [key]: null }); return true; }
  // Уже принятый бой/вываживание завершаем, новый не начинаем: следующий проход вернёт прежний режим.
  const timeExpired = key === 'dailyFish' && D.readyUntil && Date.now() >= D.readyUntil;
  if (env.isBattle() || (key === 'dailyFish' && env.fishState?.() && !timeExpired)) return false;
  await detourEnd(key, D, 'кампания не завершена — дейлик отложен');
  return true;
}
function fishLack() { const t = dailyTask('fishing_catch_50'); return t && !t.done ? Math.max(1, t.need - t.have) : 0; }
function rbWanted() {
  const a = dailyTask('strong_enemy_20'), b = dailyTask('raid_boss_participate');
  const C = env.rt.clanTasks, mine = C?.active?.find(t => t.id === C.me?.active);
  return !!((a && !a.done) || (b && !b.done) || (mine && mine.type === 'kill_raid_boss' && mine.progress < mine.target));
}
async function dailyStep() {
  if (!canRun()) return false;
  const kick = +env.rt.manualKickAt || 0;
  const F = env.rt.dailyFish, R = env.rt.dailyRb;
  // Прерванный старый detour не имеет права возвращать настройки поверх более нового ручного выбора.
  for (const [key, D] of [['dailyFish', F], ['dailyRb', R]]) if (D && D.kick != null && D.kick !== kick) { await env.setRt({ [key]: null }); return true; }
  if (F) {
    if (env.dailyFishBlocked?.() && !env.fishState?.()) { await detourEnd('dailyFish',F,'дневной лимит рыбы достигнут');return true; }
    if (fishTakenOver(F)) { await env.setRt({ dailyFish: null }); return true; }
    if (campaignBusy() && (F.readyUntil || !env.fishState?.())) return yieldCampaign('dailyFish', F, kick);
    if (env.cfg.dailyAuto === false) { await detourEnd('dailyFish', F, 'дейлики выключены'); return true; }
    const done = (F.got || 0) >= F.need, late = Date.now() - (F.t || 0) > FISH_MAX, dq = dailyTask('fishing_catch_50');
    if (done || late || (dq && dq.done)) { await detourEnd('dailyFish', F, done || dq?.done ? `рыба на дейлик поймана (${F.got}/${F.need})` : 'рыбалка по дейлику: 45 мин вышли'); return true; }
    // Старое/прерванное задание после reload сначала подтверждает готовность, не попадает в fishSetup.
    if (!F.readyUntil) {
      // GET безопасен и с рыбой на крючке: legacy без срока иначе застрянет при нулевом времени.
      if (env.isBattle()) return false;
      const ready = await fishReady(kick);
      if (!sameDetour('dailyFish', F, kick)) return false;
      if (!ready) { await detourEnd('dailyFish', F, 'рыбалка не подготовлена — дейлик отложен'); return true; }
      await env.setRt({ dailyFish: { ...F, readyUntil: ready.until } });
      return true;
    }
    // Без времени вываживание уже невозможно: не зацикливаем fishSoft/reload в ожидании исчезновения рыбы.
    if (Date.now() >= F.readyUntil && !env.isBattle()) { await detourEnd('dailyFish', F, 'оплаченное время рыбалки закончилось — дейлик отложен'); return true; }
    if (F.entering) return enterDetour('dailyFish', F, kick);
    return false;
  }
  if (R) {
    if (campaignBusy()) return yieldCampaign('dailyRb', R, kick);
    if (env.cfg.dailyAuto === false) { await detourEnd('dailyRb', R, 'дейлики выключены'); return true; }
    // 20.12 (решение игрока 17.10 10:56): тур РБ дейлик больше сам не включает — начатый старой версией заход заканчивается, режимы возвращаются
    await detourEnd('dailyRb', R, 'тур РБ по дейлику больше не включается сам'); return true;
  }
  if (env.cfg.dailyAuto === false || !env.rt.daily?.day || campaignBusy() || env.isBattle() || !env.awayFree?.() || env.fishNow()) return false;
  // 15.10: строгий список сам выбирает режим; дейлик не меняет порядок и не запускает чужую задачу.
  if (Array.isArray(env.cfg.autoTasks)) return false;
  const lack = fishLack();
  if ((!Array.isArray(env.cfg.autoTasks) || env.cfg.autoTasks.includes('fish')) && lack && !env.dailyFishBlocked?.() && !doneDay('fish') && !env.cfg.fishMode) {
    const char = env.rt.char, ready = await fishReady(kick);
    if (!canRun() || (+env.rt.manualKickAt || 0) !== kick || env.rt.char !== char || env.cfg.dailyAuto === false || campaignBusy() || env.isBattle() || !env.awayFree?.() || env.fishNow()) return false;
    if (ready) {
      const J = { day: env.rt.daily.day, need: lack, got: 0, t: Date.now(), prev: snap(), entering: true, kick, readyUntil: ready.until };
      await env.setRt({ dailyFish: J, dailyDone: { ...(env.rt.dailyDone || {}), fish: env.rt.daily.day } });
      if (await enterDetour('dailyFish', J, kick) && env.rt.dailyFish && !campaignBusy()) env.rec('B', 'дейлики', `«50 рыб»: не хватает ${lack} — иду на рыбалку (+1 Coin of Luck, 300 000 аден, 50 000 EXP), потом назад`);
      return true;
    }
  }
  // 20.12 (решение игрока 17.10 10:56: «тур по РБ не должен быть авто включённым»): «Убей 1 РБ» дейлик сам тур не включает —
  // засчитывается, когда игрок сам выбрал «Тур РБ» (тот берёт свой бафф за FA по rbFaFull)
  return false;
}
// 10.0.14: запись задания и переключение режима разделены await. Stop/новый ручной режим не дают старому шагу
// включить рыбалку/тур. Незавершённый вход переживает перезапуск; ручной выбор в popup отменяет само задание.
const sameDetour = (key, D, kick) => canRun() && (+env.rt.manualKickAt || 0) === kick && (D.kick == null || D.kick === kick) && env.rt[key]?.t === D.t && env.rt[key]?.day === D.day;
async function enterDetour(key, D, kick) {
  if (!sameDetour(key, D, kick) || env.cfg.dailyAuto === false) return false;
  if (campaignBusy()) return yieldCampaign(key, D, kick);
  await env.setCfg(key === 'dailyFish' ? { fishMode: true, rbHuntMode: false, epicMode: false, catMode: false, zoneAuto: false }
    : { rbHuntMode: true, fishMode: false, epicMode: false, catMode: false });
  if (!sameDetour(key, D, kick)) return true;
  if (campaignBusy()) return yieldCampaign(key, D, kick);
  await env.setRt({ [key]: { ...D, entering: false } });
  if (key === 'dailyRb' && sameDetour(key, D, kick)) try { await env.rbRun?.start('daily', 'дейлик'); } catch (e) {}
  return true;
}
async function detourEnd(key, D, why) {
  const kick = +env.rt.manualKickAt || 0;
  if (!sameDetour(key, D, kick)) return;
  await env.setCfg({ ...(D.prev || {}) });
  if (!sameDetour(key, D, kick)) return;
  await env.setRt({ [key]: null, ...(key === 'dailyRb' ? { rbHunt: { step: 'pick', t: Date.now(), last: 'дейлик по РБ окончен' }, rbGo: null } : {}) });
  if (!canRun() || (+env.rt.manualKickAt || 0) !== kick) return;
  env.rec('B', 'дейлики', `${why} — возвращаюсь к прежнему режиму`);
  env.setStatus?.(`Дейлик: ${why} — возвращаюсь`);
  if (key === 'dailyFish' && !env.cfg.fishMode && /fishing/.test(location.pathname)) { location.href = '/map.html'; await env.sleep(3000); }
}
async function fishNote() { const F = env.rt.dailyFish; if (!F) return; await env.setRt({ dailyFish: { ...F, got: (F.got || 0) + 1 } }); }
// ---------- текст для меню ----------
function text() {
  const D = env.rt.daily, C = env.rt.clanTasks, out = [];
  if (D?.tasks) out.push(`📅 Дейлики (день ${D.day}): ` + Object.entries(D.tasks).map(([id, t]) => `${t.done ? '✓' : '○'} ${DAILY_RU[id] || id}${t.done ? '' : ` ${t.have}/${t.need}`}`).join(' · '));
  else out.push('📅 Дейлики: ещё не читал (опрос раз в 10 мин)');
  if (env.rt.dailyFish) out.push(`🎣 ловлю рыбу на дейлик: ${env.rt.dailyFish.got || 0}/${env.rt.dailyFish.need}`);
  if (env.rt.dailyRb) out.push('🏹 иду убить РБ на дейлик');
  if (C?.noClan) out.push('🏰 Клан: героя нет в клане');
  else if (C?.defs) {
    const mine = C.active.find(t => t.id === C.me.active);
    out.push(`🏰 ${C.clan.name}: алмазов ${C.clan.diamonds}` + (mine ? ` · моё задание: «${nameOf(C, mine.type)}» ${mine.progress}/${mine.target}${mine.canClaim ? ' — готово к сдаче' : ''}` : ' · задания нет'));
    const others = C.active.filter(t => t.id !== C.me.active); if (others.length) out.push('   соклановцы: ' + others.map(t => `${t.owner}: «${nameOf(C, t.type)}» ${t.progress}/${t.target}`).join('; '));
    out.push('   доступно: ' + C.defs.map(d => `${d.canTake ? '✓' : d.why === 'cooldown' && d.cdAt ? '⏳ ' + new Date(d.cdAt).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' }) : '○'} ${d.n} (+${d.diamonds}💎${d.reward.coinOfLuck ? ', ' + d.reward.coinOfLuck + ' CoL' : d.reward.adena ? ', ' + d.reward.adena.toLocaleString('ru') + ' аден' : d.reward.exp ? ', ' + d.reward.exp.toLocaleString('ru') + ' EXP' : ''})`).join(' · '));
  } else out.push('🏰 Клановые задания: ещё не читал');
  return out.join('\n');
}
return { DAILY_RU, CLAN_TYPES, dailyNote, clanNote, tick, clanPlan, clanStep, dailyStep, detourEnd, fishNote, fishLack, rbWanted, text };
 };
})(typeof globalThis !== 'undefined' ? globalThis : this);
