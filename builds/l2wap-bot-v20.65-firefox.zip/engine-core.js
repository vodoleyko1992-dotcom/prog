/* L2wap runtime infrastructure v6.0.0.
 * This file has no DOM/chrome dependencies and is regression-tested in Node.
 */
(function (root) {
  'use strict';
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

  function createRecoveryController(clock = () => Date.now()) {
    const errors = new Map(), fatalSignatures = new Map();
    // Count failures per route rather than penalizing unrelated subsystems.
    function failure(route, error) {
      const now = clock(), key = String(route || 'unknown').slice(0, 128);
      let series = (errors.get(key) || []).filter(t => now - t < 30 * 60000);
      series.push(now); errors.set(key, series);
      const recent = series.filter(t => now - t < 10 * 60000).length;
      const total = series.length, message = String(error?.message || error || '').slice(0, 180);
      const network = /(?:failed to fetch|networkerror|network request failed|net::err_|fetch failed|timeout|background_timeout|502|503|504)/i.test(message);
      const programming = !network && (
        error instanceof ReferenceError || error instanceof SyntaxError || error instanceof TypeError ||
        /(?:cannot read properties|cannot set properties|is not (?:a )?function|is not defined|illegal invocation|undefined.*\.test)/i.test(message));
      // The same programming exception twice cannot be repaired by sleeping or reloading.
      let fatalRepeats = 0;
      if (programming) {
        const previous = fatalSignatures.get(key);
        fatalRepeats = previous?.message === message && now - previous.at < 10 * 60000 ? previous.count + 1 : 1;
        fatalSignatures.set(key, { message, count: fatalRepeats, at: now });
      }
      const delayMs = clamp(Math.round(1500 * Math.pow(1.7, Math.min(recent - 1, 8))), 1500, 30000);
      // 7.1.14-fix: «Cannot read properties of null/undefined» — обычно гонка с загрузкой страницы: 2-я подряд — перезагрузка,
      // стоп только на 4-й без прогресса. Настоящие ошибки кода («is not a function») — стоп со 2-го раза, как было
      const domRace = programming && /cannot (?:read|set) properties of (?:null|undefined)/i.test(message);
      const action = programming ? (domRace ? (fatalRepeats >= 4 ? 'halt' : fatalRepeats >= 2 ? 'reload' : 'retry') : fatalRepeats >= 2 ? 'halt' : 'retry') :
        total >= 18 ? 'halt' : recent >= 6 ? 'cooldown' :
        recent >= 3 && recent % 3 === 0 ? 'reload' : 'retry';
      return { route: key, action, delayMs: programming ? 1500 : delayMs, recent, total,
        error: message, programming, fatalRepeats, times: series.slice(-30) };
    }
    function restore(route, timestamps) {
      const key = String(route || 'unknown').slice(0, 128), now = clock();
      errors.set(key, (Array.isArray(timestamps) ? timestamps : []).filter(t => Number.isFinite(t) && t <= now && now - t < 30 * 60000).slice(-30));
    }
    function progress(route) { const k = String(route || 'unknown').slice(0, 128); errors.delete(k); fatalSignatures.delete(k); }
    function count(route) { return (errors.get(String(route || 'unknown').slice(0, 128)) || []).length; }
    // 8.0 (аудит ядра): счётчик повторов ошибки кода жил только в памяти страницы — после перезагрузки снова «1-й раз»,
    // и «Cannot read properties of undefined» перезагружал страницу бесконечно (раз в ≈7 с). Теперь его можно сохранить и вернуть
    function exportFatal(route) { const v = fatalSignatures.get(String(route || 'unknown').slice(0, 128)); return v ? { ...v } : null; }
    function restoreFatal(route, v) {
      const now = clock();
      if (v && typeof v.message === 'string' && Number.isFinite(v.count) && Number.isFinite(v.at) && v.at <= now && now - v.at < 10 * 60000)
        fatalSignatures.set(String(route || 'unknown').slice(0, 128), { message: v.message, count: v.count, at: v.at });
    }
    return { failure, progress, count, restore, exportFatal, restoreFatal };
  }

  function createTransitionMonitor(clock = () => Date.now()) {
    const pending = new Map();
    function expect(key, fromPage, timeoutMs = 20000) {
      pending.set(String(key), { fromPage, at: clock(), timeoutMs: clamp(timeoutMs, 1000, 120000) });
    }
    function check(key, page) {
      const k = String(key), p = pending.get(k);
      if (!p) return 'none';
      if (page !== p.fromPage) { pending.delete(k); return 'complete'; }
      if (clock() - p.at >= p.timeoutMs) { pending.delete(k); return 'timeout'; }
      return 'pending';
    }
    function clear(key) { pending.delete(String(key)); }
    return { expect, check, clear };
  }

  // Prevent background IPC from indefinitely freezing a navigation or state write.
  // Browser native timers require their Window receiver in some contexts.
  // Exposing them as bare object methods (timers.set = setTimeout) causes
  // TypeError: Illegal invocation in Chromium when called as timers.set(...).
  function withTimeout(promise, ms, timers = {
    set: (fn, delay) => setTimeout(fn, delay),
    clear: id => clearTimeout(id)
  }) {
    return new Promise((resolve, reject) => {
      const id = timers.set(() => reject(new Error('background_timeout')), ms);
      Promise.resolve(promise).then(
        v => { timers.clear(id); resolve(v); },
        e => { timers.clear(id); reject(e); }
      );
    });
  }

  // Detect a "live" loop with no observable progress. Unlike a heartbeat,
  // this requires a changing page, battle HP, objective or job state.
  function createProgressMonitor(clock = () => Date.now()) {
    let signature = null, changedAt = clock(), lastAlarm = 0;
    function tick(next, active, timeoutMs = 9 * 60000) {
      if (!active) { signature = null; changedAt = clock(); return 'idle'; }
      const s = String(next);
      if (signature !== s) { signature = s; changedAt = clock(); return 'progress'; }
      const now = clock();
      if (now - changedAt >= timeoutMs && now - lastAlarm >= timeoutMs) {
        lastAlarm = now; return 'stalled';
      }
      return 'waiting';
    }
    function snapshot() { return { signature, changedAt, lastAlarm }; }
    return { tick, snapshot };
  }

  // One exclusive autonomous mode controls navigation. Manual jobs, PvP and
  // combat remain higher-priority interrupts in the content-script dispatcher.
  function chooseMode({ enchant = false, craft = false, epic = false, raid = false, fish = false, cat = false, campaign = false, tasks = false } = {}) {
    if (enchant) return 'enchant'; // 15.10: отдельный режим сильнее старых флагов импортированного профиля.
    if (craft) return 'craft'; // 22.10: отдельный режим использует очередь материалов и МП-банки.
    if (epic) return 'epic';
    if (raid) return 'raid';
    if (fish) return 'fish';
    if (cat && !campaign) return 'cat';
    if (campaign) return 'campaign';
    if (tasks) return 'tasks';     // 10.0 (игрок 12.10: «старт без быстрого режима»): режима нет — только задачи (Маммон, квесты, цель фарма, TvT)
    return 'farm';
  }

  // 15.10: явный список задач ограничивает и старые флаги импортированных профилей.
  const TASK_KEYS = ['tvt','quests','fish','cat','raid','epic','farm','auto','enchant','craft','mammon','dailies','clan','pvp','petbuff','resources'];
  const taskRaw = new WeakMap();
  const rawTaskConfig = c => taskRaw.get(c) || c;
  const taskList = c => Array.isArray(rawTaskConfig(c)?.autoTasks) ? TASK_KEYS.filter(k => rawTaskConfig(c).autoTasks.includes(k)) : null;
  const taskAllowed = (c, key) => taskList(c) === null || taskList(c).includes(key);
  // 19.10: дневные квоты сбрасываются в полночь сервера; /game/time задаёт часы и зону (с учётом DST).
  // 20.10 (игрок 17.10 04:33: «мобы на автофарм и каты — общие!»): один дневной лимит мобов на обе охоты, счётчики auto/cat складываются.
  const dailyKeys = {fish:'dailyFishLimit',auto:'dailyKillLimit',cat:'dailyKillLimit'};
  const dayFormats = new Map();
  const serverDay = (now,zone='Europe/Kyiv') => {
    if(!dayFormats.has(zone))dayFormats.set(zone,new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'}));
    const p=Object.fromEntries(dayFormats.get(zone).formatToParts(now).map(x=>[x.type,x.value]));return `${p.year}-${p.month}-${p.day}`;
  };
  const serverClockNote = (data,at=Date.now()) => {
    if(!data || !Number.isSafeInteger(data.serverNowMs) || !Number.isSafeInteger(data.nextDailyResetAt) || data.nextDailyResetAt<=data.serverNowMs || data.nextDailyResetAt-data.serverNowMs>26*3600000 || typeof data.timeZone!=='string')return null;
    const key=String(data.gameDayKey||'').replace(/^(\d{4})(\d{2})(\d{2})$/,'$1-$2-$3');
    try {if(serverDay(data.serverNowMs,data.timeZone)!==key)return null;}catch(_){return null;}
    return {at,serverNowMs:data.serverNowMs,timeZone:data.timeZone,gameDayKey:key,nextDailyResetAt:data.nextDailyResetAt};
  };
  const dailyDay = (now=Date.now(),rt={}) => {
    const c=rt.serverClock;
    if(c && Number.isFinite(c.at) && Number.isFinite(c.serverNowMs) && now>=c.at) {
      const serverNow=c.serverNowMs+(now-c.at);
      if(serverNow<c.nextDailyResetAt && /^\d{4}-\d{2}-\d{2}$/.test(c.gameDayKey))return c.gameDayKey;
      try{return serverDay(serverNow,c.timeZone);}catch(_){}
    }
    return serverDay(now);
  };
  // 20.43 (разбор 21.10): меню писало «до 00:00 сервера», а сервер считает сутки по Киеву — у игрока (UTC+10) это 07:00 или 08:00
  // смотря по переходу Киева на зимнее время. Момент сброса в часах этого компьютера: из /game/time (rt.serverClock, с поправкой на
  // расхождение часов), без него — ближайшая полночь Europe/Kyiv. Только показ: сам дневной счёт по-прежнему решает dailyDay.
  const wallFormats = new Map();
  const zoneMidnightAfter = (t, zone) => {
    if(!wallFormats.has(zone))wallFormats.set(zone,new Intl.DateTimeFormat('en-CA',{timeZone:zone,hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}));
    const wall=x=>Object.fromEntries(wallFormats.get(zone).formatToParts(x).map(p=>[p.type,+p.value])), off=x=>{const p=wall(x);return Date.UTC(p.year,p.month-1,p.day,p.hour%24,p.minute,p.second)-Math.floor(x/1000)*1000;};
    const p=wall(t), target=Date.UTC(p.year,p.month-1,p.day+1);
    let at=target-off(t); at=target-off(at); return target-off(at);   // два уточнения: полночь после перевода часов внутри этих суток
  };
  const dailyResetAt = (now=Date.now(),rt={}) => {
    const c=rt?.serverClock;
    if(c && Number.isFinite(c.at) && Number.isFinite(c.serverNowMs) && now>=c.at) {
      const serverNow=c.serverNowMs+(now-c.at);
      if(Number.isFinite(c.nextDailyResetAt) && serverNow<c.nextDailyResetAt)return now+(c.nextDailyResetAt-serverNow);
      try{return now+(zoneMidnightAfter(serverNow,c.timeZone)-serverNow);}catch(_){}
    }
    return zoneMidnightAfter(now,'Europe/Kyiv');
  };
  // «сброс в 07:00 по Владивостоку (через 3 ч 12 мин)» — часы игрока, как у блока PvE в меню (Asia/Vladivostok)
  const dailyResetText = (now=Date.now(),rt={}) => {
    const at=dailyResetAt(now,rt), m=Math.max(1,Math.ceil((at-now)/60000)), h=Math.floor(m/60), mm=m%60;
    const hhmm=new Date(Math.round(at/60000)*60000).toLocaleTimeString('ru-RU',{timeZone:'Asia/Vladivostok',hour:'2-digit',minute:'2-digit'});
    return `сброс в ${hhmm} по Владивостоку (через ${h?h+' ч'+(mm?' '+mm+' мин':''):mm+' мин'})`;
  };
  // Однократно переносим старые сутки UTC+10 без выдачи дополнительного дневного бюджета.
  const dailyCurrent = (row,rt={},now=Date.now()) => !!row && (row.day===dailyDay(now,rt) || row.basis!=='server' && row.day===new Date(now+10*3600000).toISOString().slice(0,10));
  const dailyQuotaToday = (rt={},now=Date.now()) => ({...(dailyCurrent(rt.dailyQuota,rt,now)?rt.dailyQuota:{fish:0,auto:0,cat:0,raid:0}),day:dailyDay(now,rt),basis:'server'});
  const dailyLimit = (c,k) => { const n = +rawTaskConfig(c)?.[dailyKeys[k]]; return Number.isSafeInteger(n) && n > 0 ? n : 0; };
  const dailyCount = (rt,k,now = Date.now()) => !dailyCurrent(rt.dailyQuota,rt,now) ? 0 : k === 'fish' ? Math.max(0,+rt.dailyQuota.fish || 0) : Math.max(0,+rt.dailyQuota.auto || 0) + Math.max(0,+rt.dailyQuota.cat || 0) + Math.max(0,+rt.dailyQuota.raid || 0) + Math.max(0,+rt.dailyQuota.server || 0);
  const dailyBlocked = (c,rt,k,now = Date.now()) => dailyLimit(c,k) > 0 && dailyCount(rt,k,now) >= dailyLimit(c,k);
  // 19.10, автономность: подтверждённая пауза рыбалки не удерживает другие выбранные занятия.
  function fishTaskWaitKey(c,rt={},now=Date.now()) {
    const raw=rawTaskConfig(c)||{};
    const keys=Object.keys(raw).filter(k=>/^(fish|rod)/.test(k)||['shopReserve','shopMaxSpend','dailyFishLimit'].includes(k)).sort();
    return JSON.stringify([rt.char||'',+rt.manualKickAt||0,rt.dailyStart||0,dailyDay(now,rt),taskList(c),keys.map(k=>[k,raw[k]])]);
  }
  function fishTaskWait(c,rt={},now=Date.now()) {
    const w=rt.taskWait?.fish,list=taskList(c);
    if(!w||!list?.includes('fish')||!list.some(k=>['raid','epic','quests','cat','auto','farm'].includes(k))||w.key!==fishTaskWaitKey(c,rt,now)
      ||!Number.isFinite(w.at)||!Number.isFinite(w.until)||now<w.at||w.until<=w.at||w.until-w.at>300000
      ||rt.fishCastActive===true||rt.fishCastPending||rt.actionPayments?.pending?.kind==='fishing'||rt.fishService||rt.fishSvc||rt.dailyFish)return null;
    // Уже начатая закупка/дорога запасной задачи завершается до возврата: короткая пауза не обрывает её на полпути.
    return w.until>now||rt.actionOwner||rt.actionPayments?.pending?w:null;
  }
  // 20.43 (автономность, разбор 21.10): «передышка» вместо стопа. Временный технический сбой (клик по мобу не открыл бой, список мобов
  // не грузится, нет прогресса 9 мин ×3) раньше выключал бота до утра. Теперь — общий шаг rt.selfHold = {kind, why, at, until, n, task,
  // mode, kick}: на это время выбранная задача (task) пропускается в selectedTask и идут другие выбранные задачи, а если их нет — бот ждёт
  // с пульсом, TvT и проверкой капчи и потом продолжает сам. Новый Старт игрока (другой manualKickAt) передышку снимает. Предел — 3 передышки
  // одного вида за 6 ч (rt.selfHoldLog[kind]): нужна 4-я — полный стоп с причиной (selfHoldPlan → stop).
  const SELF_HOLD_WINDOW = 6 * 3600000, SELF_HOLD_MAX = 3;
  // 20.43 (автономность, доводка 21.10): передышки — по задаче, rt.selfHold = {ключ: передышка}. Раньше ячейка была одна, и новая передышка
  // молча затирала прежнюю: [тур, фарм] при общем сбое карты — тур на передышке, идёт фарм, его передышка «mob» стирала туровую, тур снова
  // выходил на сломанную карту и стирал фермерскую; передышки сменяли друг друга, счёт «3 за 6 ч» набегал за 30–40 мин. Ключ — задача
  // (режим задач), режим (без списка) или вид (передышка без своей задачи — только запрет клика по карте). Старая одиночная запись читается.
  const selfHoldKey = h => h?.task ? String(h.task) : h?.mode ? 'mode:' + h.mode : 'kind:' + String(h?.kind || '');
  function selfHoldMap(rt = {}) {
    const v = rt?.selfHold;
    if (!v || typeof v !== 'object' || Array.isArray(v)) return {};
    if (['kind', 'until', 'at', 'why'].some(k => Object.hasOwn(v, k))) return { [selfHoldKey(v)]: v };   // запись до доводки 21.10
    return Object.fromEntries(Object.entries(v).filter(([, h]) => h && typeof h === 'object' && !Array.isArray(h)));
  }
  const selfHoldValid = (h, rt = {}, now = Date.now()) => !!h && typeof h === 'object' && Number.isFinite(+h.until) && Number.isFinite(+h.at) && +h.at <= now + 60000 && +h.until > now
    && (+h.kick || 0) === (+rt?.manualKickAt || 0);
  const selfHoldList = (rt = {}, now = Date.now()) => Object.values(selfHoldMap(rt)).filter(h => selfHoldValid(h, rt, now));
  // pick — отбор (функция); без него — первая действующая (совместимость: одна передышка — она и есть)
  function selfHoldActive(rt = {}, now = Date.now(), pick = null) {
    return selfHoldList(rt, now).find(h => typeof pick !== 'function' || pick(h)) || null;
  }
  // 20.43 (автономность, ревью): window — окно учёта вида. Запрет маршрута длится 2 ч, поэтому 4-й запрет одного маршрута не укладывался в 6 ч
  // никогда: маршрут зацикливался снова после каждого запрета (с новой оплатой телепорта/баффов) без стопа и уведомления. Запрет — окно 12 ч
  function selfHoldPlan(rt = {}, kind = '', steps = [30], now = Date.now(), window = SELF_HOLD_WINDOW) {
    const span = Number.isFinite(+window) && +window > 0 ? +window : SELF_HOLD_WINDOW;
    const log = (Array.isArray(rt?.selfHoldLog?.[kind]) ? rt.selfHoldLog[kind] : []).filter(t => Number.isFinite(+t) && now - t < span && t <= now);
    if (log.length >= SELF_HOLD_MAX) return { stop: true, n: log.length, log };
    const list = Array.isArray(steps) && steps.length ? steps : [30], min = +list[Math.min(log.length, list.length - 1)] || 30;
    return { stop: false, n: log.length + 1, ms: min * 60000, log: [...log, now] };
  }
  // 20.10: явный запуск тура выбрасывает прежний список живых/мёртвых, а не боевую память и платежи.
  function raidFreshStartPatch(rt = {}, c = {}, now = Date.now()) {
    const raw = rawTaskConfig(c) || {}, list = taskList(c);
    if (!(list ? list.includes('raid') : raw.rbHuntMode || raw.rbMode)) return {};
    const protective = rt.rbHuntIdle > now && rt.rbRefuse?.n >= 2 && now - (rt.rbRefuse.t || 0) < 600000;
    const seq = Number.isSafeInteger(rt.rbListStartSeq) && rt.rbListStartSeq >= 0 && rt.rbListStartSeq < Number.MAX_SAFE_INTEGER ? rt.rbListStartSeq + 1 : 1;
    return { rbList:{}, rbListT:0, rbListVerifiedAt:0, rbListIncomplete:true,
      rbListReadStart:null, rbListStartSeq:seq, rbListStartRequired:`${rt.dailyStart || 0}:${rt.manualKickAt || 0}:${seq}`,
      rbTourView:null, rbFishWait:null, rbListVerifyNextAt:0,
      ...(protective ? {} : { rbHuntIdle:0, rbIdleMark:null, rbIdleN:0 }) };
  }
  // 20.43 (автономность, ревью): base — выбор игрока без автоматических пропусков: передышки (rt.selfHold) и ожидания тура на рыбалке
  // (rt.rbFishWait, в том числе отсрочки кота). Это «режим маршрута» (baseTask → content.routeMode): контекст владельца служебного маршрута
  // (actions.context) и задания Маммона. Раньше в контексте был фактический выбор, и конец передышки/ожидания выглядел как «пользователь
  // сменил режим»: начатый поход к Маммону (после платного телепорта) или «Закупить сейчас» отменялись, герой оставался у NPC
  function selectedTask(c, rt = {}, now = Date.now(), base = false) {
    const list = taskList(c); if (list === null) return null;
    const fishWait=fishTaskWait(c,rt,now);
    const fishOpen = rt.fishCastActive === true || !fishWait && !dailyBlocked(c,rt,'fish',now) && !rt.fishTgt?.done && !(+rawTaskConfig(c).fishMaxCasts > 0 && (+rt.fish?.casts || 0) >= +rawTaskConfig(c).fishMaxCasts);
    const wait = base || rt.rbListStartRequired != null && rt.rbListReadStart !== rt.rbListStartRequired ? null : rt.rbFishWait, idleRaid = wait && rt.rbHunt?.phase === 'wait' && (!rt.rbHunt?.step || rt.rbHunt.step === 'pick') && !rt.rbHunt?.id && !rt.rbGo && !rt.rbPending;
    const fishBusy = rt.fishCastActive === true || !!rt.fishCastPending || rt.actionPayments?.pending?.kind === 'fishing';
    // 20.28 (лог 20.10 08:51): подготовка услуги Маммона не возвращает отложенный рейд.
    // Сам pending по-прежнему запрещает повторную оплату; удерживать рейд должен его собственный телепорт.
    const raidPayment = rt.actionPayments?.pending?.kind === 'raid-teleport';
    const freshRaid = rt.rbTourView?.at > (wait?.at || 0) && rt.rbTourView?.ready?.length > 0;
    // 20.43 (автономность): задача на передышке уступает другим; начатый заброс доводится. Доводка 21.10: передышек может быть несколько
    const held = base ? [] : selfHoldList(rt, now).map(h => h.task).filter(Boolean);
    return ['enchant','craft','epic','raid','quests','fish','cat','auto','farm'].find(k => {
      if (!list.includes(k) || dailyBlocked(c,rt,k,now) && !(k === 'fish' && fishBusy)) return false;
      if (held.includes(k) && k !== 'enchant' && !(k === 'fish' && fishBusy)) return false;
      if (k === 'enchant') return !['done','completed'].includes(rt.enchant?.status);
      if (k === 'raid' && list.includes('fish') && (fishOpen || fishBusy || fishWait) && idleRaid && (!raidPayment || fishWait && rt.actionOwner) && (fishBusy || fishWait && rt.actionOwner || wait.until > now && !freshRaid)) return false;
      if (k === 'fish') return fishOpen || !!idleRaid && fishBusy;
      if (k === 'quests') {
        const live = [rt.storySaga,rt.dionCampaign].some(q => q && !q.completed && q.stage !== 'completed');
        return !(rt.campNoTasksUntil > now && !live && !(rt.questList || []).length); // Только подтверждённое отсутствие; ошибка главы не разрешает другую задачу.
      }
      return true;
    }) || 'tasks';
  }
  const baseTask = (c, rt = {}, now = Date.now()) => selectedTask(c, rt, now, true);
  // 20.65 (жалоба John 25.10 «бот грузит ЦП»; замер боя: прокси cfg ≈160 мс/мин, ≈62 000 чтений cfg.X в минуту): selectedTask
  // считается только для ключей, которые прокси подменяет (таблицы ниже — общие для набора и для ветвей), остальные ключи — как есть
  const TC_GROUPS = {
    mammon: ['mmOrders','mmUpgrade','mmShopBuy','mmSmithAuto','mmCraftSend','mmCraftNote','mmMailClaim','mmGoalFarm'],
    quests: ['storyTurnIn','campAuto'], dailies: ['dailyAuto'], clan: ['clanTasks'], // searchQuest — приоритет местных ★ мобов, а не разрешение вести кампанию.
    pvp: ['enemyHunt','pvpOnSight','pvpAll'], petbuff: ['petFullAuto'], resources: ['subHelpMain','mmFarmBest','mmFarmGuide'],
  };
  const TC_SUPPORT = ['autoMagister','weaponScanAuto','weaponClassEquip','weaponAuto','shopAuto','townBuff','autoLearn'];
  const TC_PRIMARY = {enchantMode:'enchant',craftMode:'craft',epicMode:'epic',rbHuntMode:'raid',rbMode:'raid',fishMode:'fish',catMode:'cat',zoneAuto:'auto',campaign:'quests'};
  const TC_SPECIAL = new Set([...Object.keys(TC_PRIMARY), ...Object.values(TC_GROUPS).flat(), ...TC_SUPPORT,
    'tvtOn','taskOnly','tvtOverRb','tsBuy','chain','farmRes','recipeRes','resQuests','mmGoalItem','mmGoalFarm','campAuto']);
  const TC_LEGACY = new Set(['fishMode','catMode','zoneAuto','taskOnly']);
  function taskConfig(input, runtime = () => ({})) {
    const raw = rawTaskConfig(input);
    if (!Array.isArray(raw?.autoTasks)) {
      if (!Object.keys(dailyKeys).some(k => dailyLimit(raw,k))) return raw;
      const view = new Proxy(raw,{get(target,key){
        if (!TC_LEGACY.has(key)) return Reflect.get(target,key);
        const rt=runtime(), tasks={fishMode:'fish',catMode:'cat',zoneAuto:'auto'};
        if (Object.hasOwn(tasks,key) && dailyBlocked(target,rt,tasks[key]) && !(key==='fishMode' && rt.fishCastActive)) return false;
        if (key==='taskOnly' && Object.entries(tasks).some(([flag,k])=>target[flag] && dailyBlocked(target,rt,k)) && !['enchantMode','craftMode','epicMode','rbHuntMode','campaign'].some(k=>target[k]) && !Object.entries(tasks).some(([flag,k])=>target[flag] && !dailyBlocked(target,rt,k))) return true;
        return Reflect.get(target,key);
      }}); taskRaw.set(view,raw); return view;
    }
    const groups = TC_GROUPS, support = TC_SUPPORT, primary = TC_PRIMARY;
    const view = new Proxy(raw, { get(target, key) {
      if (!TC_SPECIAL.has(key)) return Reflect.get(target,key);
      let a1; const act = () => a1 === undefined ? (a1 = selectedTask(target, runtime())) : a1, allowed = k => taskAllowed(target, k);
      if (Object.hasOwn(primary,key)) return primary[key] === act();
      if (key === 'tvtOn') return allowed('tvt');
      if (key === 'taskOnly') return act() === 'tasks';
      if (key === 'tvtOverRb') return true;
      if (key === 'tsBuy') return false; // Покупка цели TvT — отдельная трата, не участие в событии.
      if (key === 'chain' && !['farm','auto','quests','cat'].includes(act())) return false;
      if (['farmRes','recipeRes','resQuests'].includes(key) && !allowed('resources')) return '';
      if (key === 'mmGoalItem' && !allowed('mammon')) return 0;
      if (key === 'mmGoalFarm' && !allowed('resources')) return false;
      for (const [group, keys] of Object.entries(groups)) if (keys.includes(key) && !allowed(group)) return false;
      if (key === 'campAuto') return false; // Кампания запускается только выбранной задачей.
      if (support.includes(key) && ['tasks','fish','enchant','craft'].includes(act())) return false;
      return Reflect.get(target,key);
    }});
    taskRaw.set(view, raw); return view;
  }
  // 20.12 (ревизия 17.10): режимы и платные разрешения — в одном месте. Базовый профиль не включает режимы
  // (чистая установка = «стоять, где оставили»), новый герой (ещё нет cfg@Ник) не наследует платные режимы предыдущего.
  const MODE_KEYS = ['craftMode','enchantMode','epicMode','rbHuntMode','rbMode','rbBetween','fishMode','catMode','zoneAuto','campaign','autoTasks','taskOnly'];
  const BASE_CFG_SKIP = [...MODE_KEYS, 'weaponManual', 'nWeaponMain'];  // ручной выбор оружия из профиля устаревает вместе со снаряжением
  const BASE_RT_SKIP = ['weapons','weaponRec','weaponEq','weaponNow','weaponsT','panel','panelSig','skills','rbK','rbDps','rbStats','hardMobs','zoneBad','lvl'];
  const NEW_HERO_PAID = {epicMode:false, epicCoinDailyMax:0, epicAdenaDailyMax:0, rbHuntMode:false, rbMode:false, rbFaFull:false, epicFaFull:false, fishTimeAuto:false, mmUpgrade:false};
  const baseProfileCfg = c => Object.fromEntries(Object.entries(c || {}).filter(([k]) => !BASE_CFG_SKIP.includes(k)));
  const baseProfileRt = r => Object.fromEntries(Object.entries(r || {}).filter(([k]) => !BASE_RT_SKIP.includes(k)));
  function newHeroCfg(prev) {
    const next = { ...(prev || {}), ...NEW_HERO_PAID, craftMode: false };
    // Явный список задач тоже выбирает режим: тур РБ, эпики и отдельный крафт новый герой включает сам.
    if (Array.isArray(next.autoTasks)) next.autoTasks = next.autoTasks.filter(k => k !== 'raid' && k !== 'epic' && k !== 'craft');
    return next;
  }
  const MANUAL_JOBS = ['shop','invScan','bagCheck','faScan','recipeScan','farmScan','zoneScan'];
  function taskJobAllowed(c, key, rt = {}) {
    // 22.10: выделенный крафт не возобновляет старые автоматические походы, даже если их службы остались в списке.
    // Разовые команды меню сохраняются; квитанции оплат хранятся отдельно от маршрутов.
    const craftOnly = taskList(c) === null ? rawTaskConfig(c)?.craftMode === true : selectedTask(c,rt) === 'craft';
    if (craftOnly) return key === 'sealEx' ? !!rt[key] && rt[key].auto !== true
      : MANUAL_JOBS.includes(key) && !!rt[key] && (rt[key].urgent === true || rt[key].manual === true);
    if (taskList(c) === null) return true;
    if (['dailyFish','dailyRb'].includes(key)) return false; // Дейлики не владеют режимом строгого списка.
    // 20.12 (ревизия 17.10, core-a/M2): разовые кнопки меню («🛒 Закупить сейчас», «Пересчитать в сумке», «Обновить список баффов FA»,
    // «Проверить оружие», чтение баз/телепорта) — явная команда игрока; раньше при выбранной рыбалке/«только задачах» их молча стирали.
    const job = rt[key];
    if (key === 'sealEx') return !!job && (job.auto !== true || c.sealAuto === true);
    if (MANUAL_JOBS.includes(key) && job && typeof job === 'object' && (job.urgent === true || job.manual === true)) return true;
    const primary = {rbGo:'raid',rbHunt:'raid',fishSvc:'fish',fishService:'fish'}[key];
    // Ожидающий тур сохраняет место возврата после выбранной рыбалки; боевые маршруты не переносятся.
    if (key === 'rbHunt' && rt.rbFishWait && rt.rbHunt?.phase === 'wait' && (!rt.rbHunt.step || rt.rbHunt.step === 'pick') && !rt.rbHunt.id && (selectedTask(c,rt) === 'fish' || fishTaskWait(c,rt))) return true;
    if (primary) return selectedTask(c,rt) === primary;
    const group = {mmJob:'mammon',storyJob:'quests',dailyFish:'fish',dailyRb:'raid',petBufferTrip:'petbuff',rbGo:'raid',rbHunt:'raid',fishSvc:'fish',fishService:'fish',farmScan:'resources',recipeScan:'resources',rbScan:'raid'}[key];
    // 20.54: сдача квеста плаща Goddard ведётся своим выключателем (goddardQuest) и без задачи «Квесты»
    if (key === 'storyJob' && rt.storyJob?.kind === 'goddard' && c.goddardQuest !== false) return true;
    if (group) return taskAllowed(c,group);
    if (key === 'tsJob') return false;
    // 17.10 (лог 15:10, West): перелёт цели «Фарм ресурсов»/рецепта — работа задачи «ресурсы», а не чужой маршрут; иначе «Только задачи» отменял его каждые 4 с.
    if (key === 'zoneGo' && (rt.zoneGo?.task === 'resources' || rt.zoneGo?.res)) return taskAllowed(c,'resources');
    // 20.43 (автономность, ревью 21.10): обратный перелёт службы (Маммон, сдача квеста — zoneGo.svc) — конец её похода, а не новая основная
    // работа. На передышке фарма выбор — «tasks», и перелёт снимался как несовместимый: герой оставался у NPC и после передышки фармил не на
    // своей точке. Решает выбор игрока без передышки (baseTask); в режиме «только задачи» / рыбалки / заточки — как прежде
    if (key === 'zoneGo' && rt.zoneGo?.svc && taskAllowed(c,rt.zoneGo.svc)) return !['tasks','fish','enchant','craft'].includes(baseTask(c,rt));
    return !['tasks','fish','enchant','craft'].includes(selectedTask(c,rt));
  }
  // 20.43 (автономность, доводка 21.10): маршрут задачи на передышке. В режиме задач передышка меняет выбор, и loopTaskList снимал маршруты
  // удерживаемой задачи как несовместимые: тур на stall-передышке (бой с РБ без изменения HP 9 мин ×3) терял rbHunt в шаге arrive/fight
  // уже после подтверждённого платного перелёта — через 20 мин тур начинал с выбора и снова платил ≈100 000 за телепорт к тому же РБ; так же
  // терялся перелёт zoneGo фарма. Теперь такой маршрут (его разрешает выбор без передышек) хранится, но до конца передышки не исполняется:
  // диспетчер и сторож вкладки его не видят (content). Застрявший маршрут, ставший причиной передышки (hold.drop), не держим — он снимается
  // как прежде. Квитанции оплат живут отдельно и не снимаются ни в одном случае.
  // Ревью: одного хранения мало — после передышки вкладка могла стоять не на карте (рыбалка), и прилёт/бой сдавались с платным выбором;
  // поэтому по концу передышки тур сначала бесплатно открывает карту (content: rt.rbResume, raidResumeMap).
  function taskJobHeld(c, key, rt = {}, now = Date.now()) {
    if (taskList(c) === null || !rt?.[key]) return false;
    const holds = selfHoldList(rt, now); if (!holds.some(h => h.task)) return false;
    if (holds.some(h => Array.isArray(h.drop) && h.drop.includes(key))) return false;
    return !taskJobAllowed(c, key, rt) && taskJobAllowed(c, key, { ...rt, selfHold: null });
  }

  // Each update is a PATCH. Never rewrite a stale copy of the full runtime state.
  // Serial execution and retry preserve update ordering even if storage is down.
  function createPatchQueue(send, canWrite = () => true, onError = () => {}, clock = () => Date.now(),
    timers = { set: (f, ms) => setTimeout(f, ms), clear: t => clearTimeout(t) }) {
    // Реворк ядра: каждая выдача замка получает свою очередь. Ответ старого запроса
    // после clear() не подтверждает новую запись и не задерживает её своим backoff.
    // 20.41 (лог 20.10 21:09, память 1,3 МБ: каждая запись ≈0,5 с и подвисание страницы): later — отложенные патчи (замеры
    // навыков после каждого удара). Они новее pending и уходят вместе с любой обычной записью, recover() или по таймеру.
    const fresh = () => ({ pending: {}, inflight: {}, flushing: null, retryAt: 0, later: {}, laterT: null });
    function promote(state) {
      if (state.laterT != null) { timers.clear(state.laterT); state.laterT = null; }
      if (Object.keys(state.later).length) { state.pending = { ...state.pending, ...state.later }; state.later = {}; }
    }
    let current = fresh();
    const cleared = () => ({ ok: false, reason: 'cleared' });
    async function drain(state) {
      while (Object.keys(state.pending).length) {
        if (state !== current) return cleared();
        if (!canWrite()) return { ok: false, reason: 'inactive' };
        const batch = state.pending; state.pending = {}; state.inflight = batch;
        try {
          const response = await send(batch);
          if (state !== current) return cleared();
          if (!response?.ok) throw new Error(response?.reason || 'storage_patch_failed');
          state.retryAt = 0; state.inflight = {};
        } catch (e) {
          if (state !== current) return cleared();
          // Более свежие значения заменяют неудачный старый пакет.
          state.pending = { ...batch, ...state.pending }; state.inflight = {};
          state.retryAt = clock() + 3000;
          onError(e);
          return { ok: false, reason: 'write_failed' };
        }
      }
      return { ok: true };
    }
    function flush(state) {
      if (!state.flushing) state.flushing = Promise.resolve().then(() => drain(state)).then(result => {
        state.flushing = null;
        if (state !== current) return cleared();
        // enqueue может попасть между последним await в drain и завершением promise.
        // Тогда его подтверждение тоже ждёт фактической записи, а не пустой старой очереди.
        return result.ok && Object.keys(state.pending).length ? flush(state) : result;
      }, error => { state.flushing = null; throw error; });
      return state.flushing;
    }
    function enqueue(patch) {
      if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new TypeError('patch must be an object');
      const state = current;
      promote(state);
      Object.assign(state.pending, patch);
      if (state.retryAt > clock()) return Promise.resolve({ ok: false, reason: 'backoff' });
      return flush(state);
    }
    function defer(patch, ms = 8000) {
      if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new TypeError('patch must be an object');
      const state = current;
      Object.assign(state.later, patch);
      if (state.laterT == null) state.laterT = timers.set(() => {
        state.laterT = null;
        if (state !== current) return;
        promote(state);
        if (state.retryAt <= clock()) flush(state).catch(onError);
      }, ms);
      return Promise.resolve({ ok: true, deferred: true });
    }
    function peek() { return { ...current.inflight, ...current.pending, ...current.later }; }
    // 20.43 (лог 21.10: путь к мобу катакомб больше не ждёт записи): при уходе со страницы пакет в полёте уже передан фону —
    // повторно шлём только неотправленное, иначе тот же пакет писался дважды и задерживал замок новой страницы
    function unsent() { return { ...current.pending, ...current.later }; }
    function recover() { promote(current); return current.flushing || (!Object.keys(current.pending).length ? Promise.resolve({ ok: true }) : enqueue({})); }
    function clear() { if (current.laterT != null) timers.clear(current.laterT); current = fresh(); }
    // 20.41 (ревью): изменение из меню новее ещё не отправленных значений тех же ключей (отложенная статистика держится до 8 с).
    // Пакет уже в полёте тоже: peek() больше не возвращает его старые значения в память вкладки, а неудачная отправка не вернёт их
    // в очередь (inflight — тот же объект, что batch). Уже отправленное отсекает фон по menuRev.
    function drop(keys) { for (const k of keys) { delete current.pending[k]; delete current.later[k]; delete current.inflight[k]; } }
    return { enqueue, defer, peek, unsent, recover, clear, drop };
  }

  // 20.43 (разбор 21.10, ночной лог alt2 Warlord 48: 40 FA за 572 боя, чемпионов из них 18 — обычным боям остаётся ≥ 22 FA на 554 боя,
  // т. е. ≥ 4 % за бой; агро собирает пачку, и в одном бою падает несколько мобов): цену чемпиона и «Cancel» бот считал по анонсу —
  // 1 % за обычный бой. Теперь шанс FA за бой — свой замер класса (rt.faRate[класс] = { k: {вид: боёв}, f: {вид: FA} }, loot.faRateNote),
  // сглаженный анонсом: (FA + анонс × N0) / (боёв + N0); N0 = 100 обычных и 30 боёв с чемпионом. Обычный бой — не ниже анонса 1 %:
  // в каждом таком бою есть хотя бы один моб с шансом 1 %, меньше бывает только при нераспознанных строках добычи (тогда — как раньше).
  // Чистые функции — для combat/champs/mobfarm и для меню (popup).
  const FA_PRIOR = Object.freeze({ mob: 0.01, blue: 0.1, orange: 0.2, red: 0.6 }), FA_N0 = Object.freeze({ mob: 100, blue: 30, orange: 30, red: 30 });
  const faClass = prof => String(prof || '').toLowerCase().replace(/^(?:dark[_\s]elf|human|elf|elven|orc|dwarf|kamael)[_\s]+/, '').replace(/[_\s-]+/g, ' ').trim() || '?';
  function faRate(S, kind) {
    const key = Object.hasOwn(FA_PRIOR, kind) ? kind : 'blue', p = FA_PRIOR[key], n0 = FA_N0[key];
    const k = Math.max(0, +S?.k?.[key] || 0), f = Math.max(0, +S?.f?.[key] || 0), r = (f + p * n0) / (k + n0);
    return key === 'mob' ? Math.max(p, r) : r;
  }

  // 7.2.3 (игрок 10.10: «окно постоянно скачет, то больше, то меньше — нравится, когда больше»): свободное поле слева от игры
  // мерится по видимым элементам, а они на разных экранах (бой, победа, карта, загрузка) разные. Запоминаем самое широкое поле
  // для этой ширины окна браузера и не сужаем окно, пока ширина браузера та же (новая ширина — мерим заново)
  // 10.0.5 (игрок 13.10, спойлер WestSPOIL: «левая панель вышла за край»): «самое широкое поле» залезало на игру — на экране, где
  // рамка игры шире (или замер по узкому блоку дал лишнее поле), окно оставалось прежней ширины и закрывало левый край игры.
  // Теперь запоминаем самое УЗКОЕ поле, реально измеренное по рамке игры (measured): окно не прыгает и никогда не залезает на игру.
  // Без замера (игра ещё грузится) — прежнее значение. Старые записи «самого широкого» (без m) заменяются первым замером
  function stickyFree(stick, free, viewport, measured = true) {
    const cap = Math.max(0, Math.floor(viewport / 2) - 16);   // игра по центру: поле слева не шире половины экрана
    const f = Math.min(Math.max(0, free | 0), cap);
    const same = stick && stick.vw === viewport ? stick : null;
    if (!measured) return same || { vw: viewport, free: 0 };
    return same && same.m && same.free <= f ? same : { vw: viewport, free: f, m: 1 };
  }

  // 23.10.2026: темп бота задаётся отдельно от серверных КД. Ждём до подготовки действия,
  // не откладываем уже помеченную отправку и не держим очередь кликов после Stop.
  function createActionPace({ delay, sleep, clock = Date.now, read = () => 0, write = () => {} }) {
    let last = 0;
    // 23.10: по просьбе игрока 0 — без дополнительной задержки; выбранную положительную паузу сохраняем.
    const gap = () => { const n = Number(delay()); return Number.isFinite(n) ? Math.max(0, Math.min(5000, n)) : 0; };
    const previous = () => {
      const now = clock(); let saved = 0;
      try { saved = Number(read()); } catch (_) {}
      // Часы могли перевести назад: будущая отметка не создаёт вечного ожидания.
      if (last > now) last = 0;
      return Math.max(last, Number.isFinite(saved) && saved > 0 && saved <= now ? saved : 0);
    };
    const left = () => { const ms = gap(); if (!ms) return 0; const at = previous(); return at > 0 ? Math.max(0, at + ms - clock()) : 0; };
    function note() { last = clock(); try { write(last); } catch (_) {} }
    async function wait(valid = () => true) {
      while (valid()) {
        const ms = left(); if (!ms) return valid();
        // Короткие части позволяют Stop, смене героя и новому значению бегунка прервать ожидание.
        await sleep(Math.min(100, ms));
      }
      return false;
    }
    return { wait, note, left, gap };
  }

  // 20.62 (жалоба John 25.10 «бот грузит ЦП и память»): тайник классов rt.classStash (память неактивных сабклассов, 600–870 КБ из
  // ≈1–1,5 МБ rt) — в своём ключе хранилища: у активного героя «stash» (рядом с «rt»), у остальных «stash@Ник» (рядом с «rt@Ник»).
  // Значение — обёртка { char, v: classStash | null, _src }. Обычная запись rt и её рассылка storage.onChanged (вкладка игры и окно
  // бота получают старое+новое значение целиком) больше не тащат тайник. В памяти вкладки/меню по-прежнему rt.classStash: читатели
  // хранилища складывают его обратно (stashJoin). Обёртка другого героя (char не совпал) не подставляется.
  // Старое rt.classStash внутри rt (ещё не перенесено; или его снова написала сборка без ключа stash — откат на старый ZIP в ту же
  // папку) новее ключа только по своим классам: ревью 20.62 — тайник старой сборки начинается с {} и держит лишь класс, с которого
  // ушли, поэтому замена ключа целиком стёрла бы память остальных классов. Складываем по классам { ...ключ, ...старое }; запись
  // ключа об активном классе (rt.classCur.prof) не берём — активный класс в тайнике не лежит, его память в самом rt.
  const STASH_RE = /^stash(@|$)/;
  const stashKeyOf = k => k === 'rt' ? 'stash' : typeof k === 'string' && /^rt@./.test(k) ? 'stash@' + k.slice(3) : null;
  const stashObj = v => v && typeof v === 'object' && !Array.isArray(v);
  function stashValue(rt, wrap) {
    const own = stashObj(wrap) && String(wrap.char || '') === String(rt?.char || '') && stashObj(wrap.v);
    if (stashObj(rt) && Object.hasOwn(rt, 'classStash')) {
      const L = rt.classStash; if (!own) return { has: true, legacy: true, v: L };
      const act = String(rt.classCur?.prof || ''), v = {};
      for (const [k, x] of Object.entries(wrap.v)) if (k !== act) v[k] = x;
      return { has: true, legacy: true, v: { ...v, ...(stashObj(L) ? L : {}) } };
    }
    if (own) return { has: true, legacy: false, v: wrap.v };
    return { has: false, legacy: false, v: undefined };
  }
  const stashJoin = (rt, wrap) => { const s = stashValue(rt, wrap); return s.has && (!s.legacy || s.v !== rt.classStash) ? { ...rt, classStash: s.v } : rt; };
  const stashWrap = (char, v, src) => ({ char: String(char || ''), v: stashObj(v) ? v : null, _src: String(src || '').slice(0, 60) });
  function stashStrip(rt) { if (!stashObj(rt) || !Object.hasOwn(rt, 'classStash')) return rt; const { classStash: _, ...rest } = rt; return rest; }
  // Запись в хранилище (объект для chrome.storage.local.set): rt/rt@Ник без classStash, тайник — в парном ключе той же записью
  function stashSplitSet(change, src) {
    for (const k of Object.keys(change)) { const sk = stashKeyOf(k), r = change[k]; if (!sk || !stashObj(r) || !Object.hasOwn(r, 'classStash')) continue;
      change[sk] = stashWrap(r.char || (k === 'rt' ? '' : k.slice(3)), r.classStash, src); change[k] = stashStrip(r); }
    return change;
  }
  // Фон (statePatch/menuPatch/stashMigrate): запись несёт старое rt.classStash из хранилища (не свой тайник пакета own — он полный, с
  // удалениями, и пишется как есть) — складываем его с ключом stash по классам; ключ читается только в этом редком случае
  async function stashLegacyMerge(change, state, own, getStash) {
    if (own || !stashObj(change?.rt) || !Object.hasOwn(state?.rt || {}, 'classStash') || !Object.hasOwn(change.rt, 'classStash')) return change;
    const w = (await getStash())?.stash; change.rt = { ...change.rt, classStash: stashValue(change.rt, w).v }; return change;
  }
  // Ревью 20.62 (2): ключ «stash» после отката на старую сборку может держать тайник другого героя (старая сборка меняла героев, не
  // трогая ключи stash*). Перед заменой «stash» тайником активного героя чужую обёртку переносим в stash@её ника, если там пусто —
  // иначе память её классов пропала бы. Читает хранилище только когда запись сама пишет «stash» (смена класса, перенос, меню)
  async function stashRehome(change, get) {
    const nw = change?.stash; if (!stashObj(nw)) return change;
    const cur = (await get(['stash']))?.stash, who = stashObj(cur) ? String(cur.char || '') : '';
    if (!who || who === String(nw.char || '') || !stashObj(cur.v) || Object.hasOwn(change, 'stash@' + who)) return change;
    const there = (await get(['stash@' + who]))?.['stash@' + who];
    if (!stashObj(there) || !stashObj(there.v)) change['stash@' + who] = cur;
    return change;
  }
  // Вкладка игры: тайник для нового rt из события storage.onChanged (ch). Старое rt.classStash уже в rt; ключ stash в этом же событии
  // (не своё эхо src) важнее; тот же герой — тайник из памяти вкладки (prev); герой сменился без ключа stash в событии — reload: ник,
  // тайник нового героя вкладка дочитывает из хранилища
  function stashKeep(prev, ch, src) {
    const n = ch?.rt?.newValue || {}, same = String(n.char || '') === String(prev?.char || '');
    // старое rt.classStash в событии (сборка без ключа stash) — по классам поверх ключа из события или тайника в памяти вкладки
    if (Object.hasOwn(n, 'classStash')) { const w = ch.stash ? ch.stash.newValue : same && stashObj(prev) && stashObj(prev.classStash) ? { char: n.char, v: prev.classStash } : null;
      const s = stashValue(n, w); return { part: s.v !== n.classStash ? { classStash: s.v } : {} }; }
    if (ch.stash && ch.stash.newValue?._src !== src) { const s = stashValue(n, ch.stash.newValue); return { part: s.has ? { classStash: s.v } : {} }; }
    if (same) return { part: stashObj(prev) && Object.hasOwn(prev, 'classStash') ? { classStash: prev.classStash } : {} };
    return { part: {}, reload: String(n.char || '') };
  }
  // Файл «Памяти бота» — прежнего вида (classStash внутри rt): выгрузка складывает тайник обратно в rt/rt@Ник, ключи stash* не пишет
  function stashFold(data) {
    const out = {};
    for (const [k, v] of Object.entries(data || {})) if (!STASH_RE.test(k)) { const sk = stashKeyOf(k); out[k] = sk && stashObj(v) ? stashJoin(v, data[sk]) : v; }
    return out;
  }
  // Загрузка файла: тайник героя — в его ключ (нет в файле — пустая обёртка, чтобы старый тайник этого слота не подставился),
  // ключи stash* без пары rt из файла не пишем
  function stashUnfold(data, src) {
    const out = {};
    for (const [k, v] of Object.entries(data || {})) {
      if (STASH_RE.test(k)) continue;
      const sk = stashKeyOf(k); if (!sk || !stashObj(v)) { out[k] = v; continue; }
      const s = stashValue(v, data[sk]); out[k] = stashStrip(v); out[sk] = stashWrap(v.char || (k === 'rt' ? '' : k.slice(3)), s.v, src);
    }
    return out;
  }

  // 20.65 (John 25.10: «что ещё можем сделать для облегчения нагрузки вообще без потери качества и скорости»; замер в Chromium: запись
  // памяти героя — ≈1,5–1,7 мс ЦП на КБ по всем процессам, у игрока 0,5–0,9 МБ): частые мелкие поля rt — счёт лимита мобов (begin/win
  // на каждого моба, 2/3 записей боя) и рыбалка (4–5 записей на заброс) — пишутся в маленький ключ «hot» рядом с rt, а не переписывают
  // весь rt. Значение — { char, v: {поле: значение}, was: {поле: каким оно было в rt}, gone: [удалённые], t0, t, _src }.
  // Любая полная запись rt (фон, меню, импорт, смена героя) несёт уже сложенные значения и очищает hot (hotStore.set: hot:null той же
  // записью); hot старше минуты (HOT_FOLD_MS) следующая запись фона складывает в полный rt, Стоп/Пауза — сразу (botControl): откат на
  // старую сборку теряет не больше минуты изменений этих полей. Убрать или переименовать поле в HOT_KEYS — только вместе с разовой
  // свёрткой hot: hotOwn не примет hot с незнакомым полем, и пропадёт весь hot, не одно поле.
  // Маленький rt (до HOT_MIN_RT символов: новый герой, после сброса) пишется целиком, как раньше: его запись и так дешёвая.
  // Чтение rt (фон, меню, вкладка) — всегда вместе с hot (hotJoin). Защита: hot действует, только пока ВСЕ его поля в rt такие же, какими
  // были при первой записи (was; порядок ключей не важен — хранилище Chrome возвращает объекты с ключами по алфавиту). Хоть одно поле
  // изменено мимо hot (старая сборка после отката, внешняя запись) — весь hot устарел и не применяется.
  const HOT_KEYS = Object.freeze(['kills','farmQuota','farmKillMark','dailyQuota','dailyFishMark','raidMobMarks',
    'fishCastPending','fishCastActive','fish','fishBaitStat','fishCdStat','fishCdLen','fishDmg','fishLag','fishSess','fishSinceProc','fishSinceProcN',
    'fishSrvMargin','fishSrvOff','fishSoftN','fishSoftT','fishTgt','fishService']);
  const HOT = new Set(HOT_KEYS), HOT_FOLD_MS = 60000, HOT_MIN_RT = 32768;
  const hotObj = v => !!v && typeof v === 'object' && !Array.isArray(v);
  // строка значения без зависимости от порядка ключей; '' — поля нет (undefined хранилище не сохраняет)
  function hotStr(v) {
    if (v === undefined || typeof v === 'function') return '';
    if (v === null || typeof v !== 'object') return JSON.stringify(v) ?? '';
    if (Array.isArray(v)) return '[' + v.map(x => x === undefined || typeof x === 'function' ? 'null' : hotStr(x)).join(',') + ']';
    return '{' + Object.keys(v).filter(k => v[k] !== undefined && typeof v[k] !== 'function').sort().map(k => JSON.stringify(k) + ':' + hotStr(v[k])).join(',') + '}';
  }
  // hot того же героя, у которого все поля rt не менялись мимо него; иначе null
  function hotOwn(hot, rt) {
    if (!hotObj(hot) || !hotObj(hot.v) || !hotObj(hot.was) || !hotObj(rt) || String(hot.char ?? '') !== String(rt.char ?? '')) return null;
    const gone = Array.isArray(hot.gone) ? hot.gone : [], keys = Object.keys(hot.was);
    if (!keys.length || Object.keys(hot.v).some(k => !Object.hasOwn(hot.was, k)) || gone.some(k => !Object.hasOwn(hot.was, k))) return null;
    return keys.every(k => HOT.has(k) && typeof hot.was[k] === 'string' && hotStr(rt[k]) === hot.was[k]) ? hot : null;
  }
  // rt из хранилища + действующий hot того же героя; без него — тот же объект
  function hotJoin(rt, hot) {
    const h = hotOwn(hot, rt); if (!h) return rt;
    const out = { ...rt, ...h.v };
    if (Array.isArray(h.gone)) for (const k of h.gone) delete out[k];
    return out;
  }
  // новое значение hot: действующий прежний hot + fields (undefined — удаление поля); raw — rt из хранилища
  function hotNext(raw, old, fields, src, now = Date.now()) {
    const h = hotOwn(old, raw), v = h ? { ...h.v } : {}, was = h ? { ...h.was } : {}, gone = new Set(h && Array.isArray(h.gone) ? h.gone : []);
    for (const [k, x] of Object.entries(fields)) {
      if (!HOT.has(k)) continue;
      if (!Object.hasOwn(was, k)) was[k] = hotStr(raw[k]);
      if (x === undefined) { delete v[k]; gone.add(k); } else { v[k] = x; gone.delete(k); }
    }
    return { char: String(raw.char ?? ''), v, was, ...(gone.size ? { gone: [...gone] } : {}), t0: h && +h.t0 > 0 ? +h.t0 : now, t: now, _src: String(src || '').slice(0, 60) };
  }
  // Запись фона: next — новый rt (из state.rt — rt уже вместе с hot). Только поля HOT_KEYS изменились — значение hot; ничего не
  // изменилось — 'same'; иначе (hot старше HOT_FOLD_MS, маленький rt, другой герой) — null: полная запись rt.
  function hotPlan(state, next, now = Date.now()) {
    const cur = state?.rt, raw = state?.rtRaw;
    if (!hotObj(cur) || !hotObj(raw) || !hotObj(next) || String(next.char ?? '') !== String(raw.char ?? '') || String(cur.char ?? '') !== String(raw.char ?? '')) return null;
    const old = hotOwn(state.hot, raw);
    if (old && now - (+old.t0 || 0) >= HOT_FOLD_MS) return null;
    const fields = {}; let n = 0;
    for (const k of new Set([...Object.keys(cur), ...Object.keys(next)])) {
      if (k === '_src' || next[k] === cur[k]) continue;
      if (!HOT.has(k)) return null;
      fields[k] = next[k]; n++;
    }
    if (!n) return 'same';
    if (!old) { let size = 0; try { size = JSON.stringify(raw).length; } catch (_) {} if (size < HOT_MIN_RT) return null; }   // раз в минуту, не на каждую запись
    return hotNext(raw, old, fields, next._src, now);
  }
  // Обёртка chrome.storage.local для фона, меню и вкладки: get с 'rt' (или null — всё) отдаёт rt вместе с hot, сам hot — только по
  // запросу; withRaw — ещё rtRaw (rt хранилища) и hot для записи фона. set с rt без hot — полная запись: hot:null той же записью
  // (если get этой обёртки hot не видел — не нужно). put(state, change) — запись фона: поменялись только частые мелкие поля —
  // пишется один маленький ключ hot вместо rt.
  function hotStore(area) {
    const A = () => area();
    let seen;   // undefined — get ещё не было, null — hot в хранилище не было
    async function get(keys, withRaw = false) {
      const all = keys == null, list = all ? null : Array.isArray(keys) ? keys : [keys];
      if (!all && !list.includes('rt')) return A().get(keys);
      const askHot = !all && list.includes('hot');
      const s = { ...(await A().get(all || askHot ? keys : [...list, 'hot'])) };   // копия: ответ хранилища не меняем
      const raw = s.rt, hot = s.hot ?? null;
      seen = hot;
      if (Object.hasOwn(s, 'rt')) s.rt = hotJoin(raw, hot);
      if (!askHot) delete s.hot;
      if (withRaw) { s.rtRaw = raw; s.hot = hot; }
      return s;
    }
    const set = items => A().set(hotObj(items) && Object.hasOwn(items, 'rt') && !Object.hasOwn(items, 'hot') && seen !== null ? { ...items, hot: null } : items);
    async function put(state, change, now = Date.now()) {
      let c = change;
      if (hotObj(c) && Object.hasOwn(c, 'rt') && !Object.hasOwn(c, 'hot') && state && Object.hasOwn(state, 'rtRaw')) {
        const h = hotPlan(state, c.rt, now), { rt: _, ...rest } = c;
        if (h === 'same') c = rest; else if (h) c = { ...rest, hot: h };
      }
      if (!Object.keys(c).length) return;
      return set(c);
    }
    return { get, set, put };
  }

  // 20.41 (ревью): чистая статистика, которую меню сбрасывает (↺ сессии, лут, память боя) и которую вкладка может держать в очереди
  // (отложенно до 8 с) или в полёте. После записи меню старые значения этих ключей из вкладки не возвращаются ни в её память,
  // ни в хранилище (фон, menuRev). Намерения/оплаты/маршруты сюда не входят: для них по-прежнему последняя запись вкладки.
  const MENU_STAT_KEYS = Object.freeze(['kills','sinceDeep','target','adena','exp','sp','lastWinT','lastBattle','packLab','buffAudit','dps','mobVal',
    'lootStat','lootStatT0','mobKills','faDrop','eff','skills','via','catInT','rbKills','loot','lootSpecial','lootValue','fightMem','fightLast','fightGroups',
    'petStat','petAdvice','petCohorts','expMark',   // 20.43 (лог 21.10 15:47–15:51): статистика кота и отметка EXP% — отложенной записью
    'zoneStat']);   // 20.43: «Сбросить замеры охоты» (mobVal, zoneStat, eff) — отложенная запись вкладки сброс не воскрешает
  root.L2EngineCore = { HOT_KEYS, HOT_FOLD_MS, HOT_MIN_RT, hotStr, hotOwn, hotJoin, hotNext, hotPlan, hotStore, stashKeyOf, stashValue, stashLegacyMerge, stashRehome, stashJoin, stashWrap, stashStrip, stashSplitSet, stashKeep, stashFold, stashUnfold, createActionPace, FA_PRIOR, FA_N0, faClass, faRate, MENU_STAT_KEYS, MODE_KEYS, BASE_CFG_SKIP, BASE_RT_SKIP, NEW_HERO_PAID, baseProfileCfg, baseProfileRt, newHeroCfg, serverClockNote, dailyCurrent, dailyQuotaToday, dailyDay, dailyResetAt, dailyResetText, dailyLimit, dailyCount, dailyBlocked, fishTaskWaitKey, fishTaskWait, SELF_HOLD_WINDOW, SELF_HOLD_MAX, selfHoldKey, selfHoldMap, selfHoldValid, selfHoldList, selfHoldActive, selfHoldPlan, raidFreshStartPatch, TASK_KEYS, taskList, taskAllowed, selectedTask, baseTask, taskConfig, rawTaskConfig, taskJobAllowed, taskJobHeld, stickyFree, createRecoveryController, createTransitionMonitor, createProgressMonitor, withTimeout, chooseMode, createPatchQueue };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.L2EngineCore;
})(typeof globalThis !== 'undefined' ? globalThis : this);
