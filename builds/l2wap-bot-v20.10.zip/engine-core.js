/* L2wap runtime infrastructure v6.0.0.
 * This file has no DOM/chrome dependencies and is regression-tested in Node.
 */
(function (root) {
  'use strict';
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

  function createRecoveryController(clock = () => Date.now()) {
    const errors = new Map(), fatalSignatures = new Map();
    // Count failures per route rather than penalizing unrelated subsystems.
    function failure(route, error) {
      const now = clock(), key = String(route || 'unknown').slice(0, 128);
      let series = (errors.get(key) || []).filter(t => now - t < 30 * 60000);
      series.push(now); errors.set(key, series);
      const recent = series.filter(t => now - t < 10 * 60000).length;
      const total = series.length, message = String(error?.message || error || '').slice(0, 180);
      const network = /(?:failed to fetch|networkerror|network request failed|net::err_|fetch failed|timeout|background_timeout|502|503|504)/i.test(message);
      const programming = !network && (
        error instanceof ReferenceError || error instanceof SyntaxError || error instanceof TypeError ||
        /(?:cannot read properties|cannot set properties|is not (?:a )?function|is not defined|illegal invocation|undefined.*\.test)/i.test(message));
      // The same programming exception twice cannot be repaired by sleeping or reloading.
      let fatalRepeats = 0;
      if (programming) {
        const previous = fatalSignatures.get(key);
        fatalRepeats = previous?.message === message && now - previous.at < 10 * 60000 ? previous.count + 1 : 1;
        fatalSignatures.set(key, { message, count: fatalRepeats, at: now });
      }
      const delayMs = clamp(Math.round(1500 * Math.pow(1.7, Math.min(recent - 1, 8))), 1500, 30000);
      // 7.1.14-fix: «Cannot read properties of null/undefined» — обычно гонка с загрузкой страницы: 2-я подряд — перезагрузка,
      // стоп только на 4-й без прогресса. Настоящие ошибки кода («is not a function») — стоп со 2-го раза, как было
      const domRace = programming && /cannot (?:read|set) properties of (?:null|undefined)/i.test(message);
      const action = programming ? (domRace ? (fatalRepeats >= 4 ? 'halt' : fatalRepeats >= 2 ? 'reload' : 'retry') : fatalRepeats >= 2 ? 'halt' : 'retry') :
        total >= 18 ? 'halt' : recent >= 6 ? 'cooldown' :
        recent >= 3 && recent % 3 === 0 ? 'reload' : 'retry';
      return { route: key, action, delayMs: programming ? 1500 : delayMs, recent, total,
        error: message, programming, fatalRepeats, times: series.slice(-30) };
    }
    function restore(route, timestamps) {
      const key = String(route || 'unknown').slice(0, 128), now = clock();
      errors.set(key, (Array.isArray(timestamps) ? timestamps : []).filter(t => Number.isFinite(t) && t <= now && now - t < 30 * 60000).slice(-30));
    }
    function progress(route) { const k = String(route || 'unknown').slice(0, 128); errors.delete(k); fatalSignatures.delete(k); }
    function count(route) { return (errors.get(String(route || 'unknown').slice(0, 128)) || []).length; }
    // 8.0 (аудит ядра): счётчик повторов ошибки кода жил только в памяти страницы — после перезагрузки снова «1-й раз»,
    // и «Cannot read properties of undefined» перезагружал страницу бесконечно (раз в ≈7 с). Теперь его можно сохранить и вернуть
    function exportFatal(route) { const v = fatalSignatures.get(String(route || 'unknown').slice(0, 128)); return v ? { ...v } : null; }
    function restoreFatal(route, v) {
      const now = clock();
      if (v && typeof v.message === 'string' && Number.isFinite(v.count) && Number.isFinite(v.at) && v.at <= now && now - v.at < 10 * 60000)
        fatalSignatures.set(String(route || 'unknown').slice(0, 128), { message: v.message, count: v.count, at: v.at });
    }
    return { failure, progress, count, restore, exportFatal, restoreFatal };
  }

  function createTransitionMonitor(clock = () => Date.now()) {
    const pending = new Map();
    function expect(key, fromPage, timeoutMs = 20000) {
      pending.set(String(key), { fromPage, at: clock(), timeoutMs: clamp(timeoutMs, 1000, 120000) });
    }
    function check(key, page) {
      const k = String(key), p = pending.get(k);
      if (!p) return 'none';
      if (page !== p.fromPage) { pending.delete(k); return 'complete'; }
      if (clock() - p.at >= p.timeoutMs) { pending.delete(k); return 'timeout'; }
      return 'pending';
    }
    function clear(key) { pending.delete(String(key)); }
    return { expect, check, clear };
  }

  // Prevent background IPC from indefinitely freezing a navigation or state write.
  // Browser native timers require their Window receiver in some contexts.
  // Exposing them as bare object methods (timers.set = setTimeout) causes
  // TypeError: Illegal invocation in Chromium when called as timers.set(...).
  function withTimeout(promise, ms, timers = {
    set: (fn, delay) => setTimeout(fn, delay),
    clear: id => clearTimeout(id)
  }) {
    return new Promise((resolve, reject) => {
      const id = timers.set(() => reject(new Error('background_timeout')), ms);
      Promise.resolve(promise).then(
        v => { timers.clear(id); resolve(v); },
        e => { timers.clear(id); reject(e); }
      );
    });
  }

  // Detect a "live" loop with no observable progress. Unlike a heartbeat,
  // this requires a changing page, battle HP, objective or job state.
  function createProgressMonitor(clock = () => Date.now()) {
    let signature = null, changedAt = clock(), lastAlarm = 0;
    function tick(next, active, timeoutMs = 9 * 60000) {
      if (!active) { signature = null; changedAt = clock(); return 'idle'; }
      const s = String(next);
      if (signature !== s) { signature = s; changedAt = clock(); return 'progress'; }
      const now = clock();
      if (now - changedAt >= timeoutMs && now - lastAlarm >= timeoutMs) {
        lastAlarm = now; return 'stalled';
      }
      return 'waiting';
    }
    function snapshot() { return { signature, changedAt, lastAlarm }; }
    return { tick, snapshot };
  }

  // One exclusive autonomous mode controls navigation. Manual jobs, PvP and
  // combat remain higher-priority interrupts in the content-script dispatcher.
  function chooseMode({ enchant = false, epic = false, raid = false, fish = false, cat = false, campaign = false, tasks = false } = {}) {
    if (enchant) return 'enchant'; // 15.10: отдельный режим сильнее старых флагов импортированного профиля.
    if (epic) return 'epic';
    if (raid) return 'raid';
    if (fish) return 'fish';
    if (cat && !campaign) return 'cat';
    if (campaign) return 'campaign';
    if (tasks) return 'tasks';     // 10.0 (игрок 12.10: «старт без быстрого режима»): режима нет — только задачи (Маммон, квесты, цель фарма, TvT)
    return 'farm';
  }

  // 15.10: явный список задач ограничивает и старые флаги импортированных профилей.
  const TASK_KEYS = ['tvt','quests','fish','cat','raid','epic','farm','auto','enchant','mammon','dailies','clan','pvp','petbuff','resources'];
  const taskRaw = new WeakMap();
  const rawTaskConfig = c => taskRaw.get(c) || c;
  const taskList = c => Array.isArray(rawTaskConfig(c)?.autoTasks) ? TASK_KEYS.filter(k => rawTaskConfig(c).autoTasks.includes(k)) : null;
  const taskAllowed = (c, key) => taskList(c) === null || taskList(c).includes(key);
  // Дневные квоты профиля: календарные сутки Владивостока, независимо от часов браузера.
  // 20.10 (игрок 17.10 04:33: «мобы на автофарм и каты — общие!»): один дневной лимит мобов на обе охоты, счётчики auto/cat складываются.
  const dailyKeys = {fish:'dailyFishLimit',auto:'dailyKillLimit',cat:'dailyKillLimit'};
  const dailyDay = (now = Date.now()) => new Date(now + 10 * 3600000).toISOString().slice(0,10);
  const dailyLimit = (c,k) => { const n = +rawTaskConfig(c)?.[dailyKeys[k]]; return Number.isSafeInteger(n) && n > 0 ? n : 0; };
  const dailyCount = (rt,k,now = Date.now()) => rt.dailyQuota?.day !== dailyDay(now) ? 0 : k === 'fish' ? Math.max(0,+rt.dailyQuota.fish || 0) : Math.max(0,+rt.dailyQuota.auto || 0) + Math.max(0,+rt.dailyQuota.cat || 0);
  const dailyBlocked = (c,rt,k,now = Date.now()) => dailyLimit(c,k) > 0 && dailyCount(rt,k,now) >= dailyLimit(c,k);
  function selectedTask(c, rt = {}, now = Date.now()) {
    const list = taskList(c); if (list === null) return null;
    const fishOpen = rt.fishCastActive === true || !dailyBlocked(c,rt,'fish',now) && !rt.fishTgt?.done && !(+rawTaskConfig(c).fishMaxCasts > 0 && (+rt.fish?.casts || 0) >= +rawTaskConfig(c).fishMaxCasts);
    const wait = rt.rbFishWait, idleRaid = wait && rt.rbHunt?.phase === 'wait' && (!rt.rbHunt?.step || rt.rbHunt.step === 'pick') && !rt.rbHunt?.id && !rt.rbGo && !rt.rbPending;
    const fishBusy = rt.fishCastActive === true || !!rt.fishCastPending || rt.actionPayments?.pending?.kind === 'fishing';
    const raidPayment = !!rt.actionPayments?.pending && rt.actionPayments.pending.kind !== 'fishing';
    const freshRaid = rt.rbTourView?.at > (wait?.at || 0) && rt.rbTourView?.ready?.length > 0;
    return ['enchant','epic','raid','quests','fish','cat','auto','farm'].find(k => {
      if (!list.includes(k) || dailyBlocked(c,rt,k,now) && !(k === 'fish' && fishBusy)) return false;
      if (k === 'enchant') return !['done','completed'].includes(rt.enchant?.status);
      if (k === 'raid' && list.includes('fish') && (fishOpen || fishBusy) && idleRaid && !raidPayment && (fishBusy || wait.until > now && !freshRaid)) return false;
      if (k === 'fish') return fishOpen || !!idleRaid && fishBusy;
      if (k === 'quests') {
        const live = [rt.storySaga,rt.dionCampaign].some(q => q && !q.completed && q.stage !== 'completed');
        return !(rt.campNoTasksUntil > now && !live && !(rt.questList || []).length); // Только подтверждённое отсутствие; ошибка главы не разрешает другую задачу.
      }
      return true;
    }) || 'tasks';
  }
  function taskConfig(input, runtime = () => ({})) {
    const raw = rawTaskConfig(input);
    if (!Array.isArray(raw?.autoTasks)) {
      if (!Object.keys(dailyKeys).some(k => dailyLimit(raw,k))) return raw;
      const view = new Proxy(raw,{get(target,key){
        const rt=runtime(), tasks={fishMode:'fish',catMode:'cat',zoneAuto:'auto'};
        if (Object.hasOwn(tasks,key) && dailyBlocked(target,rt,tasks[key]) && !(key==='fishMode' && rt.fishCastActive)) return false;
        if (key==='taskOnly' && Object.entries(tasks).some(([flag,k])=>target[flag] && dailyBlocked(target,rt,k)) && !['enchantMode','epicMode','rbHuntMode','campaign'].some(k=>target[k]) && !Object.entries(tasks).some(([flag,k])=>target[flag] && !dailyBlocked(target,rt,k))) return true;
        return Reflect.get(target,key);
      }}); taskRaw.set(view,raw); return view;
    }
    const groups = {
      mammon: ['mmOrders','mmUpgrade','mmShopBuy','mmSmithAuto','mmCraftSend','mmCraftNote','mmMailClaim','mmGoalFarm'],
      quests: ['storyTurnIn','campAuto'], dailies: ['dailyAuto'], clan: ['clanTasks'], // searchQuest — приоритет местных ★ мобов, а не разрешение вести кампанию.
      pvp: ['enemyHunt','pvpOnSight'], petbuff: ['petFullAuto'], resources: ['subHelpMain','mmFarmBest','mmFarmGuide'],
    };
    const support = ['autoMagister','weaponScanAuto','weaponClassEquip','weaponAuto','shopAuto','townBuff','sealAuto','autoLearn'];
    const view = new Proxy(raw, { get(target, key) {
      const active = selectedTask(target, runtime()), allowed = k => taskAllowed(target, k);
      const primary = {enchantMode:'enchant',epicMode:'epic',rbHuntMode:'raid',rbMode:'raid',fishMode:'fish',catMode:'cat',zoneAuto:'auto',campaign:'quests'};
      if (Object.hasOwn(primary,key)) return primary[key] === active;
      if (key === 'tvtOn') return allowed('tvt');
      if (key === 'taskOnly') return active === 'tasks';
      if (key === 'tvtOverRb') return true;
      if (key === 'tsBuy') return false; // Покупка цели TvT — отдельная трата, не участие в событии.
      if (key === 'chain' && !['farm','auto','quests','cat'].includes(active)) return false;
      if (['farmRes','recipeRes','resQuests'].includes(key) && !allowed('resources')) return '';
      if (key === 'mmGoalItem' && !allowed('mammon')) return 0;
      if (key === 'mmGoalFarm' && !allowed('resources')) return false;
      for (const [group, keys] of Object.entries(groups)) if (keys.includes(key) && !allowed(group)) return false;
      if (key === 'campAuto') return false; // Кампания запускается только выбранной задачей.
      if (support.includes(key) && ['tasks','fish','enchant'].includes(active)) return false;
      return Reflect.get(target,key);
    }});
    taskRaw.set(view, raw); return view;
  }
  function taskJobAllowed(c, key, rt = {}) {
    if (taskList(c) === null) return true;
    if (['dailyFish','dailyRb'].includes(key)) return false; // Дейлики не владеют режимом строгого списка.
    const primary = {rbGo:'raid',rbHunt:'raid',fishSvc:'fish',fishService:'fish'}[key];
    // Ожидающий тур сохраняет место возврата после выбранной рыбалки; боевые маршруты не переносятся.
    if (key === 'rbHunt' && rt.rbFishWait && rt.rbHunt?.phase === 'wait' && (!rt.rbHunt.step || rt.rbHunt.step === 'pick') && !rt.rbHunt.id && selectedTask(c,rt) === 'fish') return true;
    if (primary) return selectedTask(c,rt) === primary;
    const group = {mmJob:'mammon',storyJob:'quests',dailyFish:'fish',dailyRb:'raid',petBufferTrip:'petbuff',rbGo:'raid',rbHunt:'raid',fishSvc:'fish',fishService:'fish',farmScan:'resources',recipeScan:'resources',rbScan:'raid'}[key];
    if (group) return taskAllowed(c,group);
    if (key === 'tsJob') return false;
    return !['tasks','fish','enchant'].includes(selectedTask(c,rt));
  }

  // Each update is a PATCH. Never rewrite a stale copy of the full runtime state.
  // Serial execution and retry preserve update ordering even if storage is down.
  function createPatchQueue(send, canWrite = () => true, onError = () => {}, clock = () => Date.now()) {
    // Реворк ядра: каждая выдача замка получает свою очередь. Ответ старого запроса
    // после clear() не подтверждает новую запись и не задерживает её своим backoff.
    const fresh = () => ({ pending: {}, inflight: {}, flushing: null, retryAt: 0 });
    let current = fresh();
    const cleared = () => ({ ok: false, reason: 'cleared' });
    async function drain(state) {
      while (Object.keys(state.pending).length) {
        if (state !== current) return cleared();
        if (!canWrite()) return { ok: false, reason: 'inactive' };
        const batch = state.pending; state.pending = {}; state.inflight = batch;
        try {
          const response = await send(batch);
          if (state !== current) return cleared();
          if (!response?.ok) throw new Error(response?.reason || 'storage_patch_failed');
          state.retryAt = 0; state.inflight = {};
        } catch (e) {
          if (state !== current) return cleared();
          // Более свежие значения заменяют неудачный старый пакет.
          state.pending = { ...batch, ...state.pending }; state.inflight = {};
          state.retryAt = clock() + 3000;
          onError(e);
          return { ok: false, reason: 'write_failed' };
        }
      }
      return { ok: true };
    }
    function flush(state) {
      if (!state.flushing) state.flushing = Promise.resolve().then(() => drain(state)).then(result => {
        state.flushing = null;
        if (state !== current) return cleared();
        // enqueue может попасть между последним await в drain и завершением promise.
        // Тогда его подтверждение тоже ждёт фактической записи, а не пустой старой очереди.
        return result.ok && Object.keys(state.pending).length ? flush(state) : result;
      }, error => { state.flushing = null; throw error; });
      return state.flushing;
    }
    function enqueue(patch) {
      if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new TypeError('patch must be an object');
      const state = current;
      Object.assign(state.pending, patch);
      if (state.retryAt > clock()) return Promise.resolve({ ok: false, reason: 'backoff' });
      return flush(state);
    }
    function peek() { return { ...current.inflight, ...current.pending }; }
    function recover() { return current.flushing || (!Object.keys(current.pending).length ? Promise.resolve({ ok: true }) : enqueue({})); }
    function clear() { current = fresh(); }
    return { enqueue, peek, recover, clear };
  }

  // 7.2.3 (игрок 10.10: «окно постоянно скачет, то больше, то меньше — нравится, когда больше»): свободное поле слева от игры
  // мерится по видимым элементам, а они на разных экранах (бой, победа, карта, загрузка) разные. Запоминаем самое широкое поле
  // для этой ширины окна браузера и не сужаем окно, пока ширина браузера та же (новая ширина — мерим заново)
  // 10.0.5 (игрок 13.10, спойлер WestSPOIL: «левая панель вышла за край»): «самое широкое поле» залезало на игру — на экране, где
  // рамка игры шире (или замер по узкому блоку дал лишнее поле), окно оставалось прежней ширины и закрывало левый край игры.
  // Теперь запоминаем самое УЗКОЕ поле, реально измеренное по рамке игры (measured): окно не прыгает и никогда не залезает на игру.
  // Без замера (игра ещё грузится) — прежнее значение. Старые записи «самого широкого» (без m) заменяются первым замером
  function stickyFree(stick, free, viewport, measured = true) {
    const cap = Math.max(0, Math.floor(viewport / 2) - 16);   // игра по центру: поле слева не шире половины экрана
    const f = Math.min(Math.max(0, free | 0), cap);
    const same = stick && stick.vw === viewport ? stick : null;
    if (!measured) return same || { vw: viewport, free: 0 };
    return same && same.m && same.free <= f ? same : { vw: viewport, free: f, m: 1 };
  }

  root.L2EngineCore = { dailyDay, dailyLimit, dailyCount, dailyBlocked, TASK_KEYS, taskList, taskAllowed, selectedTask, taskConfig, rawTaskConfig, taskJobAllowed, stickyFree, createRecoveryController, createTransitionMonitor, createProgressMonitor, withTimeout, chooseMode, createPatchQueue };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.L2EngineCore;
})(typeof globalThis !== 'undefined' ? globalThis : this);
